package com.phoenix.pet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlay = 4101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 23) permissions.add(Manifest.permission.RECORD_AUDIO)
        if (permissions.isNotEmpty()) requestPermissions(permissions.toTypedArray(), 4102)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF07110D.toInt())
        }
        val title = TextView(this).apply {
            text = "PHOENIX PET"
            textSize = 30f
            setTextColor(0xFF62F59A.toInt())
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "\nYour green-glow robot companion.\n\nEnable overlay permission to float Phoenix above other apps. Open chat to type or talk; Phoenix can speak replies aloud."
            textSize = 16f
            setTextColor(0xFFE4F3E9.toInt())
            gravity = Gravity.CENTER
        }
        val start = Button(this).apply {
            text = "Enable floating Phoenix"
            setOnClickListener { enablePet() }
        }
        val chat = Button(this).apply {
            text = "Open Phoenix chat"
            setOnClickListener { startActivity(Intent(this@MainActivity, ChatActivity::class.java)) }
        }
        val stop = Button(this).apply {
            text = "Stop floating pet"
            setOnClickListener {
                stopService(Intent(this@MainActivity, PetOverlayService::class.java))
                Toast.makeText(this@MainActivity, "Phoenix stopped", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(start)
        root.addView(chat)
        root.addView(stop)
        setContentView(root)
    }

    private fun enablePet() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, requestOverlay)
            return
        }
        startPetService()
    }

    private fun startPetService() {
        val intent = Intent(this, PetOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Phoenix is floating!", Toast.LENGTH_SHORT).show()
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) startPetService()
    }
}
