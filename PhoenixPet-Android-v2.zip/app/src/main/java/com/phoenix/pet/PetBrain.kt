package com.phoenix.pet

/**
 * Offline demo brain. This is intentionally transparent: it is a small local
 * response engine, not a hosted LLM. Replace reply() with a private backend
 * or on-device model integration when one is configured.
 */
object PetBrain {
    fun reply(message: String): String {
        val q = message.trim().lowercase()
        if (q.isBlank()) return "I didn't catch that. Try saying something."
        return when {
            listOf("hello", "hi", "hey", "namaste").any { q.contains(it) } ->
                "Hello! I'm Phoenix, your little green-glow companion. What shall we do?"
            q.contains("your name") || q.contains("who are you") ->
                "I'm Phoenix Pet: a tiny robot companion living on your screen."
            q.contains("time") ->
                "I can't read a live clock in this offline demo, but your Android status bar can."
            q.contains("help") ->
                "I can chat with simple offline replies, listen to speech, and speak my responses. More AI can be connected later."
            q.contains("joke") ->
                "Why did the robot bring a pencil? It wanted to draw its own conclusions. Beep boop!"
            q.contains("thank") ->
                "You're welcome! Always happy to help."
            q.contains("bye") ->
                "See you later! I'll be right here when you need me."
            else ->
                "I heard you say: \"$message\". I'm running in offline demo mode, so I don't have a full AI model connected yet."
        }
    }
}
