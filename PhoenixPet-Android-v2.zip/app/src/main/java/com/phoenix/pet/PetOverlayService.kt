package com.phoenix.pet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class PetOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var petView: LinearLayout? = null
    private var panel: LinearLayout? = null
    private var expanded = false
    private var params: WindowManager.LayoutParams? = null
    private val green = Color.rgb(83, 255, 145)
    private val moods = listOf("🤖" to "READY", "😄" to "HAPPY", "🤔" to "THINKING", "😴" to "SLEEPY", "🎉" to "EXCITED")
    private var moodIndex = 0
    private var pulseRunning = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(7, buildNotification())
        showPet()
    }

    private fun buildNotification(): Notification {
        val channelId = "phoenix_pet_running"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Phoenix Pet", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("Phoenix Pet is active")
            .setContentText("Your floating robot companion is on screen.")
            .setSmallIcon(android.R.drawable.star_on)
            .setContentIntent(open).setOngoing(true).build()
    }

    private fun showPet() {
        if (petView != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(9, 8, 9, 8)
            background = roundBg(0xE610241B.toInt(), green, 3, 34f)
            elevation = 16f
        }
        val face = TextView(this).apply { text = moods[moodIndex].first; textSize = 38f; gravity = Gravity.CENTER; tag = "face" }
        val label = TextView(this).apply { text = "PHOENIX"; textSize = 9f; setTextColor(green); gravity = Gravity.CENTER; tag = "label" }
        root.addView(face); root.addView(label)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 220 }
        params = lp
        root.setOnTouchListener(DragTouchListener(root, lp))
        root.setOnClickListener { togglePanel() }
        petView = root
        wm.addView(root, lp)
        startIdleAnimation(root)
    }

    private fun startIdleAnimation(view: View) {
        if (pulseRunning) return
        pulseRunning = true
        view.animate().scaleX(1.08f).scaleY(1.08f).alpha(0.88f).setDuration(900)
            .setInterpolator(AccelerateDecelerateInterpolator()).withEndAction {
                view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(900)
                    .setInterpolator(AccelerateDecelerateInterpolator()).withEndAction {
                        pulseRunning = false
                        if (petView === view) startIdleAnimation(view)
                    }.start()
            }.start()
    }

    private fun updateMood() {
        val view = petView ?: return
        val face = view.findViewWithTag<TextView>("face")
        val label = view.findViewWithTag<TextView>("label")
        face?.text = moods[moodIndex].first
        label?.text = "PHOENIX • " + moods[moodIndex].second
        face?.animate()?.rotationBy(12f)?.setDuration(180)?.withEndAction {
            face.animate().rotation(0f).setDuration(180).start()
        }?.start()
    }

    private fun togglePanel() {
        if (expanded) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            panel = null; expanded = false; return
        }
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            background = roundBg(0xF20A1710.toInt(), green, 2, 18f)
            elevation = 18f
        }
        val heading = TextView(this).apply { text = "PHOENIX  •  ${moods[moodIndex].second}"; textSize = 14f; setTextColor(green) }
        val message = TextView(this).apply { text = "Beep boop! Your companion is here."; textSize = 13f; setTextColor(Color.WHITE); setPadding(0, 8, 0, 10) }
        val mood = menuAction("Change expression  ✨") {
            moodIndex = (moodIndex + 1) % moods.size
            updateMood()
            heading.text = "PHOENIX  •  ${moods[moodIndex].second}"
            message.text = "New expression unlocked ${moods[moodIndex].first}"
        }
        val chat = menuAction("Open AI chat  💬") {
            val i = Intent(this, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        val hello = menuAction("Say hello  🔊") {
            Toast.makeText(this, "Hello! I'm Phoenix 🤖", Toast.LENGTH_SHORT).show()
            message.text = "Hello! I'm Phoenix. Ready when you are."
        }
        val close = menuAction("Close") { togglePanel() }
        menu.addView(heading); menu.addView(message); menu.addView(mood); menu.addView(chat); menu.addView(hello); menu.addView(close)
        val p = params ?: return
        val menuLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = p.x; y = p.y + (petView?.height ?: 80) + 8 }
        panel = menu; expanded = true; wm.addView(menu, menuLp)
    }

    private fun menuAction(text: String, action: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 14f; setTextColor(green); setPadding(0, 9, 0, 9)
        setOnClickListener { action() }
    }

    private fun roundBg(fill: Int, stroke: Int, strokeWidth: Int, radius: Float) =
        GradientDrawable().apply { setColor(fill); setCornerRadius(radius); setStroke(strokeWidth, stroke) }

    private inner class DragTouchListener(private val view: View, private val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        private var startX = 0; private var startY = 0
        private var downX = 0f; private var downY = 0f; private var moved = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = lp.x; startY = lp.y; downX = event.rawX; downY = event.rawY; moved = false; return true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    try { wm.updateViewLayout(view, lp) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> { if (!moved) view.performClick(); return true }
            }
            return false
        }
    }

    override fun onDestroy() {
        petView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        petView = null; panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
