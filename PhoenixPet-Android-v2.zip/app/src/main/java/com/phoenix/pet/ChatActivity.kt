package com.phoenix.pet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class ChatActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private val voiceRequest = 501
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 18)
            setBackgroundColor(0xFF07110D.toInt())
        }
        val title = TextView(this).apply {
            text = "🤖  PHOENIX CHAT"
            textSize = 24f
            setTextColor(0xFF62F59A.toInt())
            gravity = Gravity.CENTER
        }
        transcript = TextView(this).apply {
            text = "Phoenix: Beep boop! I'm ready.\n"
            textSize = 16f
            setTextColor(0xFFE4F3E9.toInt())
            setPadding(4, 12, 4, 12)
        }
        val scroll = ScrollView(this).apply { addView(transcript) }
        input = EditText(this).apply {
            hint = "Message Phoenix..."
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AB4A4.toInt())
        }
        val send = Button(this).apply {
            text = "Send"
            setOnClickListener { sendMessage(input.text.toString()) }
        }
        val speak = Button(this).apply {
            text = "🎙 Speak"
            setOnClickListener { startVoiceInput() }
        }
        val speakReplies = Button(this).apply {
            text = "🔊 Repeat last reply"
            setOnClickListener {
                val last = transcript.text.toString().substringAfterLast("Phoenix: ", "")
                if (last.isNotBlank()) say(last)
            }
        }
        root.addView(title)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input)
        root.addView(send)
        root.addView(speak)
        root.addView(speakReplies)
        setContentView(root)
    }

    private fun sendMessage(message: String) {
        if (message.isBlank()) return
        transcript.append("You: $message\n")
        val answer = PetBrain.reply(message)
        transcript.append("Phoenix: $answer\n\n")
        input.setText("")
        say(answer)
    }

    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition is unavailable on this device.", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5011)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to Phoenix")
        }
        try { startActivityForResult(intent, voiceRequest) }
        catch (_: Exception) { Toast.makeText(this, "Could not start voice input.", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!words.isNullOrBlank()) sendMessage(words)
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale.getDefault()
    }

    private fun say(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "phoenix-reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
