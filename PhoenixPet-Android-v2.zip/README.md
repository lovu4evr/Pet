# Phoenix Pet for Android — v2.0

Native Kotlin Android companion with a draggable floating robot, green glow, mood expressions, idle animation, voice input, text-to-speech, and a small offline chat engine.

## Features
- Floating draggable robot overlay.
- Green glow and idle breathing/pulse animation.
- Expressions: ready, happy, thinking, sleepy, excited.
- Tap the floating pet for a mini menu.
- Voice input through Android speech recognition.
- Spoken responses through Android Text-to-Speech.
- Offline rule-based chat demo. It is **not a full LLM** and makes no network/API calls.
- Foreground notification while the overlay is active.

## Build locally
Open this project folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.20
- Gradle: 8.7 (used by GitHub Actions)
- Compile SDK: 35
- Minimum Android: 6.0 / API 23

## Build automatically on GitHub
Push the extracted project contents (not the ZIP itself) to the root of a GitHub repository. The workflow at `.github/workflows/android.yml` builds a debug APK on every push and lets you download it from Actions > latest workflow run > Artifacts.

## First launch
1. Install the APK.
2. Open Phoenix Pet and grant microphone permission when asked.
3. Tap Enable floating Phoenix and grant Display over other apps permission.
4. Tap the floating robot to change expressions or open chat.
5. Use Open Phoenix chat to type or speak; Phoenix can read replies aloud.

## Important limitations
- Android speech recognition may use the device's speech service and may require internet depending on the installed provider and language.
- Text-to-Speech requires an installed Android TTS voice.
- The offline demo brain is intentionally simple. To use a real AI model, connect a model running locally on-device or a secured backend. Never commit API keys to GitHub.
- Android may stop long-running services under battery restrictions; allow background activity if your device requires it.
