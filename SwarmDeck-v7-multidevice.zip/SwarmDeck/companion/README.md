# SwarmDeck Companion

Lets the SwarmDeck phone app (with your approval on the phone for every action) see and control this computer.

    pip install pyautogui pillow        # optional: screenshots, mouse, keyboard
    python swarmdeck_companion.py       # add --pair to forget the old phone and show a new code
    python test_companion.py            # self-test of the protocol (no GUI needed)

Options: `--host 127.0.0.1` (local only), `--port 8765`, `--config PATH`.
Terminal commands while running: `resume` (after the phone halted it), `status`, `quit`.
Add apps the phone may open in `~/.swarmdeck_companion.json`, as argv lists:

    {"apps": {"vscode": ["code", "--new-window"]}}

Never exposes a shell. Use it only on networks you trust: requests are signed, not encrypted.
