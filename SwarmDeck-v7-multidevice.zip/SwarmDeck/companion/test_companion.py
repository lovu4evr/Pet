import base64, json, os, tempfile, threading, unittest, urllib.request, urllib.error
from http.server import ThreadingHTTPServer
import swarmdeck_companion as sc


class FakeBackend:
    def __init__(self, gui=True):
        self.calls = []
        self.gui = gui
        self.screen = (2560, 1440)

    def gui_available(self): return self.gui
    def size(self): return self.screen
    def screenshot_jpeg(self, mw, q): self.calls.append(("shot", mw, q)); return b"JPEGDATA", 1280, 720
    def click(self, x, y, b, n): self.calls.append(("click", x, y, b, n))
    def move(self, x, y): self.calls.append(("move", x, y))
    def scroll(self, n): self.calls.append(("scroll", n))
    def write(self, t): self.calls.append(("write", t))
    def hotkey(self, t): self.calls.append(("hotkey", tuple(t)))
    def clipboard_get(self): return "clip"
    def clipboard_set(self, t): self.calls.append(("clipset", t))
    def launch(self, argv): self.calls.append(("launch", tuple(argv)))
    def open_url(self, u): self.calls.append(("url", u))


class Clock:
    def __init__(self): self.t = 1_700_000_000.0
    def __call__(self): return self.t


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.cfg = os.path.join(self.tmp, "cfg.json")
        self.clock = Clock()
        self.be = FakeBackend()
        self.st = sc.State(self.cfg, self.be, self.clock)
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), sc.make_handler(self.st))
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.base = "http://127.0.0.1:%d" % self.srv.server_address[1]
        self.n = 0

    def tearDown(self):
        self.srv.shutdown()
        self.srv.server_close()

    def key(self, code=None):
        salt = base64.b64decode(self.info()["salt"])
        return sc.derive_key(code or self.st.code, salt)

    def info(self):
        return json.loads(urllib.request.urlopen(self.base + "/info").read())

    def post(self, key, action, args=None, path="/act", ts=None, nonce=None, raw=None, tick=0.2):
        body = raw if raw is not None else json.dumps({"action": action, "args": args or {}}).encode()
        self.n += 1
        ts = int(self.clock.t) if ts is None else ts
        nonce = nonce or ("nonce%08d" % self.n)
        req = urllib.request.Request(self.base + path, data=body, method="POST", headers={
            "X-Ts": str(ts), "X-Nonce": nonce, "X-Sig": sc.sign(key, ts, nonce, body), "Content-Type": "application/json"})
        try:
            r = urllib.request.urlopen(req)
            return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())
        finally:
            self.clock.t += tick


class CryptoVectors(unittest.TestCase):
    def test_known_answers_for_kotlin(self):
        salt = bytes(range(16))
        key = sc.derive_key("ABCD2345", salt)
        sig = sc.sign(key, 1700000000, "0123456789abcdef", b'{"action":"ping","args":{}}')
        print("\nKAT key =", key.hex(), "\nKAT sig =", sig)
        self.assertEqual(len(key), 32)
        self.assertEqual(sc.derive_key("abcd2345", salt), key)      # case-insensitive
        self.assertEqual(sc.derive_key("ABCD2345 ", salt), key)     # trimmed
        self.assertEqual(sc.derive_key("A8CD2345", salt), sc.derive_key("ABCD2345".replace("B", "8"), salt))
        self.assertEqual(sc.normalize_code("oIl0"), "0110")


class Pairing(Base):
    def test_info_is_public_and_has_no_secrets(self):
        i = self.info()
        self.assertFalse(i["paired"])
        self.assertNotIn("key", i)
        self.assertNotIn("code", i)
        self.assertEqual(i["apps"], sorted(sc.default_apps().keys()))

    def test_pairing_with_code_then_persists(self):
        code = self.st.code
        s, r = self.post(self.key(code), "ping")
        self.assertEqual((s, r["ok"], r["data"]["pong"]), (200, True, True))
        self.assertTrue(self.info()["paired"])
        self.assertEqual(self.st.code, "")
        # a new process loads the saved key and needs no code
        st2 = sc.State(self.cfg, FakeBackend(), self.clock)
        self.assertTrue(st2.paired)
        self.assertEqual(st2.key, self.st.key)
        self.assertEqual(oct(os.stat(self.cfg).st_mode & 0o777), "0o600")

    def test_wrong_code_is_rejected_and_not_paired(self):
        s, r = self.post(self.key("ZZZZ9999"), "ping")
        self.assertEqual(s, 401)
        self.assertFalse(self.info()["paired"])

    def test_expired_code(self):
        key = self.key()
        self.clock.t += sc.CODE_TTL + 1
        s, r = self.post(key, "ping", ts=int(self.clock.t))
        self.assertEqual(s, 401)
        self.assertIn("expired", r["error"])

    def test_force_pair_forgets_old_phone(self):
        self.post(self.key(), "ping")
        st2 = sc.State(self.cfg, FakeBackend(), self.clock, force_pair=True)
        self.assertFalse(st2.paired)
        self.assertNotEqual(st2.key, self.st.key)


class Security(Base):
    def setUp(self):
        super().setUp()
        self.k = self.key()
        self.assertEqual(self.post(self.k, "ping")[0], 200)

    def test_replay_and_clock_skew(self):
        self.assertEqual(self.post(self.k, "ping", nonce="fixednonce1")[0], 200)
        s, r = self.post(self.k, "ping", nonce="fixednonce1")
        self.assertEqual((s, r["error"]), (401, "replayed request"))
        s, r = self.post(self.k, "ping", ts=int(self.clock.t) - 120)
        self.assertEqual(s, 401)
        self.assertIn("clock", r["error"])

    def test_bad_signatures_lock_the_server(self):
        bad = bytes(32)
        for _ in range(sc.BAD_SIG_LIMIT):
            self.assertEqual(self.post(bad, "ping")[0], 401)
        s, r = self.post(self.k, "ping")
        self.assertEqual(s, 429)
        self.clock.t += 61
        self.assertEqual(self.post(self.k, "ping", ts=int(self.clock.t))[0], 200)

    def test_rate_limit(self):
        codes = [self.post(self.k, "ping", tick=0)[0] for _ in range(12)]
        self.assertIn(429, codes)
        self.clock.t += 2
        self.assertEqual(self.post(self.k, "ping", ts=int(self.clock.t))[0], 200)

    def test_tampered_body_and_oversize(self):
        body = json.dumps({"action": "ping", "args": {}}).encode()
        ts, nonce = int(self.clock.t), "tamper0001"
        sig = sc.sign(self.k, ts, nonce, body)
        req = urllib.request.Request(self.base + "/act", data=body.replace(b"ping", b"pong"), method="POST",
                                     headers={"X-Ts": str(ts), "X-Nonce": nonce, "X-Sig": sig})
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(req)
        self.assertEqual(cm.exception.code, 401)
        s, r = self.post(self.k, "ping", raw=b"x" * (sc.MAX_BODY + 1))
        self.assertEqual(s, 413)

    def test_missing_headers_and_unknown_paths(self):
        req = urllib.request.Request(self.base + "/act", data=b"{}", method="POST")
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(req)
        self.assertEqual(cm.exception.code, 401)
        s, r = self.post(self.k, "ping", path="/nope")
        self.assertEqual(s, 404)

    def test_halt_pauses_everything_but_ping(self):
        s, r = self.post(self.k, "", path="/halt", raw=b"{}")
        self.assertEqual((s, r["data"]["paused"]), (200, True))
        s, r = self.post(self.k, "screenshot")
        self.assertFalse(r["ok"])
        self.assertIn("paused", r["error"])
        self.assertTrue(self.post(self.k, "ping")[1]["ok"])
        self.st.resume()
        self.assertTrue(self.post(self.k, "screenshot")[1]["ok"])


class Actions(Base):
    def setUp(self):
        super().setUp()
        self.k = self.key()

    def act(self, action, args=None):
        return self.post(self.k, action, args)[1]

    def test_screenshot_then_click_maps_coordinates(self):
        r = self.act("click", {"x": 10, "y": 10})
        self.assertFalse(r["ok"])
        self.assertIn("screenshot first", r["error"])
        r = self.act("screenshot")
        self.assertEqual((r["data"]["width"], r["data"]["height"]), (1280, 720))
        self.assertEqual(base64.b64decode(r["data"]["b64"]), b"JPEGDATA")
        r = self.act("click", {"x": 640, "y": 360, "double": True})
        self.assertTrue(r["ok"])
        self.assertIn(("click", 1280, 720, "left", 2), self.be.calls)
        self.assertFalse(self.act("click", {"x": 2000, "y": 1})["ok"])
        self.assertFalse(self.act("click", {"x": 1, "y": 1, "button": "middle"})["ok"])
        self.assertTrue(self.act("mouse_move", {"x": 1280, "y": 720})["ok"])
        self.assertIn(("move", 2559, 1439), self.be.calls)

    def test_type_and_scroll_validation(self):
        self.assertTrue(self.act("type", {"text": "hello\nworld"})["ok"])
        self.assertFalse(self.act("type", {"text": "héllo"})["ok"])
        self.assertFalse(self.act("type", {"text": "x" * 501})["ok"])
        self.assertFalse(self.act("type", {})["ok"])
        self.assertTrue(self.act("scroll", {"amount": -5})["ok"])
        self.assertFalse(self.act("scroll", {"amount": 99})["ok"])
        self.assertFalse(self.act("scroll", {"amount": True})["ok"])

    def test_keys_blocked_and_allowed(self):
        self.assertTrue(self.act("key", {"combo": "ctrl+c"})["ok"])
        self.assertIn(("hotkey", ("ctrl", "c")), self.be.calls)
        self.assertTrue(self.act("key", {"combo": "Enter"})["ok"])
        self.assertTrue(self.act("key", {"combo": "ctrl+shift+t"})["ok"])
        for bad in ["win+r", "cmd+space", "Windows+R", "ctrl+alt+delete", "ctrl+shift+esc", "alt+f4", "win", "super", "ctrl+alt+t", "alt+F2"]:
            r = self.act("key", {"combo": bad})
            self.assertFalse(r["ok"], bad)
            self.assertIn("blocked", r["error"], bad)
        for weird in ["", "ctrl+", "a+b+c+d+e", "ctrl+ñ", "ctrl+f13"]:
            self.assertFalse(self.act("key", {"combo": weird})["ok"], weird)

    def test_open_url_and_apps(self):
        self.assertTrue(self.act("open_url", {"url": "https://example.com/a"})["ok"])
        for bad in ["file:///etc/passwd", "javascript:alert(1)", "ftp://x", "example.com", "https://x.com/" + "a" * 600]:
            self.assertFalse(self.act("open_url", {"url": bad})["ok"], bad)
        app = sorted(sc.default_apps().keys())[0]
        self.assertTrue(self.act("open_app", {"name": app.upper()})["ok"])
        self.assertEqual(self.be.calls[-1], ("launch", tuple(sc.default_apps()[app])))
        r = self.act("open_app", {"name": "powershell"})
        self.assertFalse(r["ok"])
        self.assertIn("not allowed", r["error"])

    def test_custom_apps_from_config_only_as_argv_lists(self):
        self.act("ping")
        with open(self.cfg, "r") as f:
            cfg = json.load(f)
        cfg["apps"] = {"MyEditor": ["code", "--new-window"], "bad": "rm -rf /", "empty": []}
        with open(self.cfg, "w") as f:
            json.dump(cfg, f)
        st2 = sc.State(self.cfg, FakeBackend(), self.clock)
        self.assertEqual(st2.apps["myeditor"], ["code", "--new-window"])
        self.assertNotIn("bad", st2.apps)
        self.assertNotIn("empty", st2.apps)

    def test_clipboard_info_and_unknown(self):
        self.assertEqual(self.act("clipboard_get")["data"]["text"], "clip")
        self.assertTrue(self.act("clipboard_set", {"text": "hi"})["ok"])
        self.assertFalse(self.act("clipboard_set", {"text": "x" * 5000})["ok"])
        self.assertEqual(self.act("screen_info")["data"]["width"], 2560)
        r = self.act("shell", {"cmd": "ls"})
        self.assertFalse(r["ok"])
        self.assertIn("unknown action", r["error"])

    def test_no_gui_reports_a_clear_error(self):
        class NoGui(FakeBackend):
            def screenshot_jpeg(self, mw, q): raise sc.ActionError("pyautogui is not installed on the computer")
        self.st.backend = NoGui(gui=False)
        self.assertFalse(self.info()["gui"])
        r = self.act("screenshot")
        self.assertFalse(r["ok"])
        self.assertIn("pyautogui", r["error"])


class Combos(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(sc.parse_combo("Ctrl + C")[0], ["ctrl", "c"])
        self.assertEqual(sc.parse_combo("CMD+Option+Esc")[0], ["win", "alt", "esc"])
        self.assertIsNone(sc.combo_blocked(["ctrl", "c"]))
        self.assertIsNone(sc.combo_blocked(["f5"]))
        self.assertEqual(sc.combo_blocked(["win"]), "the Start menu / launcher")


def raw_request(host, port, method, path, headers, body, max_body=3_000_000):
    """Python mirror of the phone's MiniHttp.kt (raw socket HTTP/1.1 client). Keeps the framing contract honest."""
    import socket
    sock = socket.create_connection((host, port), timeout=5)
    try:
        head = "%s %s HTTP/1.1\r\nHost: %s:%d\r\nConnection: close\r\n" % (method, path, host, port)
        for k, v in headers.items():
            head += "%s: %s\r\n" % (k, v)
        if body is not None:
            head += "Content-Length: %d\r\n" % len(body)
        head += "\r\n"
        sock.sendall(head.encode("latin-1") + (body or b""))
        f = sock.makefile("rb")
        line = f.readline()
        if not line:
            raise IOError("empty reply")
        parts = line.decode("latin-1").rstrip("\r\n").split(" ", 2)
        if len(parts) < 2 or not parts[0].startswith("HTTP/"):
            raise IOError("not an HTTP reply")
        status = int(parts[1])
        length = -1
        while True:
            h = f.readline().decode("latin-1").rstrip("\r\n")
            if h == "":
                break
            i = h.find(":")
            if i > 0 and h[:i].strip().lower() == "content-length":
                length = int(h[i + 1:].strip())
        data = f.read(length) if length >= 0 else f.read(max_body)
        if length >= 0 and len(data) != length:
            raise IOError("truncated reply body")
        return status, data
    finally:
        sock.close()


class RawSocketClient(Base):
    def test_info_ping_and_errors_over_a_raw_socket(self):
        host, port = "127.0.0.1", self.srv.server_address[1]
        status, data = raw_request(host, port, "GET", "/info", {}, None)
        self.assertEqual(status, 200)
        info = json.loads(data)
        key = sc.derive_key(self.st.code, base64.b64decode(info["salt"]))
        body = json.dumps({"action": "ping", "args": {}}).encode()
        ts, nonce = int(self.clock.t), "rawnonce0001"
        hdr = {"Content-Type": "application/json", "X-Ts": str(ts), "X-Nonce": nonce, "X-Sig": sc.sign(key, ts, nonce, body)}
        status, data = raw_request(host, port, "POST", "/act", hdr, body)
        self.assertEqual((status, json.loads(data)["data"]["pong"]), (200, True))
        status, data = raw_request(host, port, "POST", "/act", hdr, body)           # same nonce again
        self.assertEqual((status, json.loads(data)["error"]), (401, "replayed request"))
        status, data = raw_request(host, port, "GET", "/nope", {}, None)
        self.assertEqual(status, 404)

    def test_large_screenshot_reply_is_read_completely(self):
        host, port = "127.0.0.1", self.srv.server_address[1]
        big = b"J" * 1_500_000
        self.be.screenshot_jpeg = lambda mw, q: (big, 1280, 720)
        key = self.key()
        body = json.dumps({"action": "screenshot", "args": {}}).encode()
        ts, nonce = int(self.clock.t), "rawnonce0002"
        hdr = {"X-Ts": str(ts), "X-Nonce": nonce, "X-Sig": sc.sign(key, ts, nonce, body)}
        status, data = raw_request(host, port, "POST", "/act", hdr, body)
        self.assertEqual(status, 200)
        self.assertEqual(base64.b64decode(json.loads(data)["data"]["b64"]), big)


if __name__ == "__main__":
    unittest.main(verbosity=1)
