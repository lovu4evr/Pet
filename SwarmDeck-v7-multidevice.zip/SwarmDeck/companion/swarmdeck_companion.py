#!/usr/bin/env python3
"""
SwarmDeck Companion - lets the SwarmDeck phone app (with your approval on the phone) see and control THIS computer.

What it can do:   screenshot, mouse move/click/scroll, type text, press keys, open a web page, open allow-listed apps, clipboard.
What it never does: run shell commands, open terminals / Run dialogs / lock screen shortcuts, accept unsigned requests.

Security model
  * Pairing: this program prints an 8-character one-time code. The phone fetches a public salt from /info and derives the
    key = PBKDF2-HMAC-SHA256(code, salt, 100000). The key itself never travels over the network.
  * Every request is signed: HMAC-SHA256(key, "v1\\n" + timestamp + "\\n" + nonce + "\\n" + body). 30 s clock window,
    nonces cannot be replayed, 10 bad signatures lock the server for 60 s, max 8 requests/second.
  * The phone asks YOU before every action. Local kill switch: Ctrl+C, or move the mouse to a screen corner (pyautogui failsafe).
    A halt from the phone pauses the companion until you type `resume` here.
  * Use it only on a network you trust (home Wi-Fi, Tailscale). Traffic is signed but not encrypted.

Install (optional GUI part):  pip install pyautogui pillow
Run:                          python swarmdeck_companion.py            (add --pair to forget the old phone and show a new code)
"""
import argparse
import base64
import hashlib
import hmac
import io
import json
import os
import platform
import secrets
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PROTOCOL = 1
CODE_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
PBKDF2_ITERS = 100_000
DEFAULT_CONFIG = os.path.join(os.path.expanduser("~"), ".swarmdeck_companion.json")
TS_WINDOW = 30
CODE_TTL = 600
MAX_BODY = 8192
MAX_TYPE = 500
MAX_URL = 500
BAD_SIG_LIMIT = 10
RATE_PER_SEC = 8


# ───────────────────────── crypto helpers (mirrored on the phone, see DeviceCrypto.kt) ─────────────────────────
def normalize_code(code):
    return code.strip().upper().replace("O", "0").replace("I", "1").replace("L", "1")


def derive_key(code, salt):
    return hashlib.pbkdf2_hmac("sha256", normalize_code(code).encode("utf-8"), salt, PBKDF2_ITERS, 32)


def sign(key, ts, nonce, body):
    msg = b"v1\n" + str(ts).encode() + b"\n" + nonce.encode() + b"\n" + body
    return hmac.new(key, msg, hashlib.sha256).hexdigest()


def new_code():
    return "".join(secrets.choice(CODE_ALPHABET) for _ in range(8))


# ───────────────────────── key-combo rules (mirrored in DeviceRules.kt) ─────────────────────────
_SYN = {
    "control": "ctrl", "ctl": "ctrl", "option": "alt", "opt": "alt", "windows": "win", "super": "win", "meta": "win",
    "cmd": "win", "command": "win", "del": "delete", "escape": "esc", "return": "enter", "pgup": "pageup", "pgdn": "pagedown",
}
_NAMED = {"enter", "tab", "space", "esc", "backspace", "delete", "up", "down", "left", "right", "home", "end",
          "pageup", "pagedown", "ctrl", "alt", "shift", "win"}
_BLOCKED = [
    ({"win", "r"}, "the Run dialog"), ({"win", "x"}, "the power-user menu"), ({"win", "l"}, "screen lock"),
    ({"win", "space"}, "the launcher"), ({"ctrl", "alt", "delete"}, "the security screen"),
    ({"ctrl", "shift", "esc"}, "the task manager"), ({"alt", "f2"}, "the Run dialog"), ({"ctrl", "alt", "t"}, "a terminal"),
    ({"alt", "f4"}, "closing windows"), ({"win", "q"}, "quit/search"),
]


def parse_combo(combo):
    """Returns (tokens, error). Tokens are normalized names."""
    parts = [p.strip().lower() for p in combo.replace(" ", "").split("+")]
    if not parts or len(parts) > 4 or any(p == "" for p in parts):
        return None, "combo must have 1-4 keys, e.g. ctrl+c"
    out = []
    for p in parts:
        p = _SYN.get(p, p)
        ok = len(p) == 1 and p.isalnum() and p.isascii()
        ok = ok or p in _NAMED
        if not ok and p.startswith("f") and p[1:].isdigit() and 1 <= int(p[1:]) <= 12:
            ok = True
        if not ok:
            return None, "unsupported key: " + p
        out.append(p)
    return out, None


def combo_blocked(tokens):
    s = set(tokens)
    if s == {"win"}:
        return "the Start menu / launcher"
    for combo, why in _BLOCKED:
        if combo <= s:
            return why
    return None


# ───────────────────────── backends (real + injectable for tests) ─────────────────────────
class ActionError(Exception):
    pass


class RealBackend:
    def __init__(self):
        self._g = None

    def _gui(self):
        if self._g is None:
            try:
                import pyautogui
            except Exception:
                raise ActionError("pyautogui is not installed on the computer: pip install pyautogui pillow")
            pyautogui.FAILSAFE = True
            pyautogui.PAUSE = 0.05
            self._g = pyautogui
        return self._g

    def gui_available(self):
        try:
            self._gui()
            return True
        except ActionError:
            return False

    def size(self):
        s = self._gui().size()
        return int(s[0]), int(s[1])

    def screenshot_jpeg(self, max_w, quality):
        img = self._gui().screenshot().convert("RGB")
        if img.width > max_w:
            h = max(1, round(img.height * max_w / img.width))
            img = img.resize((max_w, h))
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=quality)
        return buf.getvalue(), img.width, img.height

    def click(self, x, y, button, clicks):
        self._gui().click(x, y, clicks=clicks, button=button)

    def move(self, x, y):
        self._gui().moveTo(x, y)

    def scroll(self, n):
        self._gui().scroll(n)

    def write(self, text):
        self._gui().write(text, interval=0.01)

    def hotkey(self, tokens):
        m = {"win": "winleft" if platform.system() == "Windows" else "command"}
        keys = [m.get(t, t) for t in tokens]
        g = self._gui()
        if len(keys) == 1:
            g.press(keys[0])
        else:
            g.hotkey(*keys)

    def clipboard_get(self):
        try:
            import pyperclip
            return pyperclip.paste()
        except Exception:
            pass
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        try:
            return r.clipboard_get()
        except tkinter.TclError:
            return ""
        finally:
            r.destroy()

    def clipboard_set(self, text):
        try:
            import pyperclip
            pyperclip.copy(text)
            return
        except Exception:
            pass
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(text)
        r.update()
        r.destroy()

    def launch(self, argv):
        subprocess.Popen(argv, shell=False, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def open_url(self, url):
        webbrowser.open(url)


def default_apps():
    sysname = platform.system()
    if sysname == "Windows":
        return {"notepad": ["notepad.exe"], "calculator": ["calc.exe"], "paint": ["mspaint.exe"]}
    if sysname == "Darwin":
        return {"textedit": ["open", "-a", "TextEdit"], "calculator": ["open", "-a", "Calculator"], "safari": ["open", "-a", "Safari"]}
    return {"text editor": ["gedit"], "calculator": ["gnome-calculator"]}


# ───────────────────────── state: pairing, auth, rate limit, actions ─────────────────────────
class State:
    def __init__(self, cfg_path=DEFAULT_CONFIG, backend=None, now=time.time, force_pair=False):
        self.cfg_path = cfg_path
        self.backend = backend or RealBackend()
        self.now = now
        self.lock = threading.Lock()
        self.paused = False
        self.nonces = {}
        self.bad = []
        self.locked_until = 0.0
        self.req_times = []
        self.last_shot = None
        self.salt = b""
        self.key = b""
        self.code = ""
        self.code_expires = 0.0
        self.paired = False
        self.apps = default_apps()
        self._load(force_pair)

    def _load(self, force_pair):
        cfg = {}
        try:
            with open(self.cfg_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        except Exception:
            cfg = {}
        for k, v in (cfg.get("apps") or {}).items():
            if isinstance(v, list) and v and all(isinstance(a, str) for a in v):
                self.apps[str(k).lower()] = v
        if not force_pair and cfg.get("key") and cfg.get("salt"):
            self.salt = base64.b64decode(cfg["salt"])
            self.key = bytes.fromhex(cfg["key"])
            self.paired = True
        else:
            self.start_pairing()

    def start_pairing(self):
        self.code = new_code()
        self.salt = secrets.token_bytes(16)
        self.key = derive_key(self.code, self.salt)
        self.code_expires = self.now() + CODE_TTL
        self.paired = False

    def _save(self):
        cfg = {"salt": base64.b64encode(self.salt).decode(), "key": self.key.hex(),
               "apps": {k: v for k, v in self.apps.items() if k not in default_apps() or default_apps()[k] != v}}
        d = os.path.dirname(self.cfg_path)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(self.cfg_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f)
        try:
            os.chmod(self.cfg_path, 0o600)
        except Exception:
            pass

    # ---- authentication ----
    def authenticate(self, headers, body):
        """Returns (http_status, error_text). 200 means authenticated."""
        with self.lock:
            now = self.now()
            if now < self.locked_until:
                return 429, "locked after too many bad signatures; wait a minute"
            try:
                ts = int(headers.get("X-Ts", ""))
                nonce = headers.get("X-Nonce", "")
                sig = headers.get("X-Sig", "")
            except ValueError:
                return 401, "missing or invalid auth headers"
            if not (8 <= len(nonce) <= 64) or not nonce.isalnum() or not sig:
                return 401, "missing or invalid auth headers"
            if abs(now - ts) > TS_WINDOW:
                return 401, "clock skew too large; sync the clocks"
            self.nonces = {n: e for n, e in self.nonces.items() if e > now}
            if nonce in self.nonces:
                return 401, "replayed request"
            if not self.paired and now > self.code_expires:
                return 401, "pairing code expired; restart with --pair"
            if not hmac.compare_digest(sign(self.key, ts, nonce, body), sig):
                self.bad = [t for t in self.bad if now - t < 60] + [now]
                if len(self.bad) >= BAD_SIG_LIMIT:
                    self.locked_until = now + 60
                    self.bad = []
                return 401, "bad signature"
            self.req_times = [t for t in self.req_times if now - t < 1.0]
            if len(self.req_times) >= RATE_PER_SEC:
                return 429, "too many requests"
            self.req_times.append(now)
            self.nonces[nonce] = now + 2 * TS_WINDOW
            if not self.paired:
                self.paired = True
                self.code = ""
                self._save()
            return 200, ""

    # ---- actions ----
    def info(self):
        gui = False
        try:
            gui = bool(self.backend.gui_available())
        except Exception:
            gui = False
        return {"v": PROTOCOL, "name": socket.gethostname(), "os": platform.system(), "salt": base64.b64encode(self.salt).decode(),
                "paired": self.paired, "paused": self.paused, "gui": gui,
                "apps": sorted(self.apps.keys())}

    def halt(self):
        self.paused = True

    def resume(self):
        self.paused = False

    def run(self, action, args):
        """Executes one validated action. Returns a data dict or raises ActionError."""
        if not isinstance(args, dict):
            raise ActionError("args must be an object")
        b = self.backend
        if action == "ping":
            return {"pong": True, "v": PROTOCOL, "paused": self.paused}
        if self.paused:
            raise ActionError("paused: type 'resume' in the companion terminal to continue")
        if action == "screen_info":
            w, h = b.size()
            return {"os": platform.system(), "width": w, "height": h}
        if action == "screenshot":
            mw = _int(args.get("max_width", 1280), 320, 1920, "max_width")
            q = _int(args.get("quality", 60), 30, 85, "quality")
            data, iw, ih = b.screenshot_jpeg(mw, q)
            sw, sh = b.size()
            self.last_shot = (iw, ih, sw, sh)
            return {"mime": "image/jpeg", "b64": base64.b64encode(data).decode(), "width": iw, "height": ih}
        if action in ("click", "mouse_move"):
            sx, sy = self._map(args)
            if action == "mouse_move":
                b.move(sx, sy)
                return {"moved": [sx, sy]}
            button = str(args.get("button", "left")).lower()
            if button not in ("left", "right"):
                raise ActionError("button must be left or right")
            b.click(sx, sy, button, 2 if args.get("double") is True else 1)
            return {"clicked": [sx, sy], "button": button}
        if action == "scroll":
            n = _int(args.get("amount", 0), -30, 30, "amount")
            b.scroll(n)
            return {"scrolled": n}
        if action == "type":
            text = args.get("text")
            if not isinstance(text, str) or not text:
                raise ActionError("text is required")
            if len(text) > MAX_TYPE:
                raise ActionError("text too long (max %d)" % MAX_TYPE)
            if not all(ch == "\n" or (32 <= ord(ch) < 127) for ch in text):
                raise ActionError("only printable ASCII can be typed")
            b.write(text)
            return {"typed": len(text)}
        if action == "key":
            tokens, err = parse_combo(str(args.get("combo", "")))
            if err:
                raise ActionError(err)
            why = combo_blocked(tokens)
            if why:
                raise ActionError("blocked key combination (%s)" % why)
            b.hotkey(tokens)
            return {"pressed": "+".join(tokens)}
        if action == "open_url":
            url = str(args.get("url", ""))
            if not (url.startswith("http://") or url.startswith("https://")) or len(url) > MAX_URL:
                raise ActionError("only http(s) URLs up to %d characters are allowed" % MAX_URL)
            b.open_url(url)
            return {"opened": url}
        if action == "open_app":
            name = str(args.get("name", "")).strip().lower()
            argv = self.apps.get(name)
            if not argv:
                raise ActionError("app not allowed. Allowed: %s. Add more under \"apps\" in %s" % (", ".join(sorted(self.apps)), self.cfg_path))
            b.launch(argv)
            return {"launched": name}
        if action == "clipboard_get":
            return {"text": str(b.clipboard_get())[:4000]}
        if action == "clipboard_set":
            text = args.get("text")
            if not isinstance(text, str) or len(text) > 4000:
                raise ActionError("text is required (max 4000)")
            b.clipboard_set(text)
            return {"set": len(text)}
        raise ActionError("unknown action: " + action)

    def _map(self, args):
        if self.last_shot is None:
            raise ActionError("take a screenshot first; coordinates refer to the last screenshot")
        iw, ih, sw, sh = self.last_shot
        x = _int(args.get("x"), 0, iw, "x")
        y = _int(args.get("y"), 0, ih, "y")
        return min(sw - 1, round(x * sw / iw)), min(sh - 1, round(y * sh / ih))


def _int(v, lo, hi, name):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v:
        raise ActionError("%s must be a number" % name)
    v = int(round(v))
    if v < lo or v > hi:
        raise ActionError("%s must be between %d and %d" % (name, lo, hi))
    return v


# ───────────────────────── HTTP ─────────────────────────
def make_handler(state, log=lambda s: None):
    class H(BaseHTTPRequestHandler):
        server_version = "SwarmDeckCompanion/1"

        def log_message(self, fmt, *a):
            pass

        def _send(self, code, obj):
            raw = json.dumps(obj).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            if self.path == "/info":
                self._send(200, state.info())
            else:
                self._send(404, {"ok": False, "error": "not found"})

        def do_POST(self):
            if self.path not in ("/act", "/halt"):
                self._send(404, {"ok": False, "error": "not found"})
                return
            try:
                n = int(self.headers.get("Content-Length", ""))
            except ValueError:
                self._send(411, {"ok": False, "error": "Content-Length required"})
                return
            if n < 0 or n > MAX_BODY:
                self._send(413, {"ok": False, "error": "body too large"})
                return
            body = self.rfile.read(n)
            status, err = state.authenticate(self.headers, body)
            if status != 200:
                log("rejected: " + err)
                self._send(status, {"ok": False, "error": err})
                return
            if self.path == "/halt":
                state.halt()
                log("HALTED by phone. Type 'resume' to continue.")
                self._send(200, {"ok": True, "data": {"paused": True}})
                return
            try:
                req = json.loads(body.decode("utf-8"))
                action = str(req["action"])
                args = req.get("args", {})
            except Exception:
                self._send(400, {"ok": False, "error": "bad request body"})
                return
            try:
                data = state.run(action, args)
                log("ok " + action)
                self._send(200, {"ok": True, "data": data})
            except ActionError as e:
                log("error %s: %s" % (action, e))
                self._send(200, {"ok": False, "error": str(e)})
            except Exception as e:
                log("failure %s: %s" % (action, e))
                self._send(200, {"ok": False, "error": "action failed: " + type(e).__name__})

    return H


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def main(argv=None):
    ap = argparse.ArgumentParser(description="SwarmDeck Companion")
    ap.add_argument("--host", default="0.0.0.0", help="address to listen on (default all interfaces)")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--pair", action="store_true", help="forget the paired phone and show a new pairing code")
    ap.add_argument("--config", default=DEFAULT_CONFIG)
    a = ap.parse_args(argv)

    st = State(a.config, force_pair=a.pair)
    srv = ThreadingHTTPServer((a.host, a.port), make_handler(st, lambda s: print(time.strftime("%H:%M:%S"), s, flush=True)))
    ip = lan_ip() if a.host in ("0.0.0.0", "") else a.host
    print("SwarmDeck Companion v%d  |  %s (%s)" % (PROTOCOL, socket.gethostname(), platform.system()))
    print("Listening on %s:%d  - use it only on a network you trust." % (a.host, a.port))
    if st.paired:
        print("Already paired with a phone. Use --pair to pair a new one.")
    else:
        print("PAIRING CODE:  %s   (valid %d minutes)" % (st.code, CODE_TTL // 60))
        print("On the phone: menu > Devices > Pair   host: %s:%d   code: %s" % (ip, a.port, st.code))
    if not st.backend.gui_available():
        print("Note: mouse/keyboard/screenshot need:  pip install pyautogui pillow")
    print("Commands here: resume | status | quit      (Ctrl+C also stops)\n", flush=True)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        if sys.stdin and sys.stdin.isatty():
            while True:
                cmd = input().strip().lower()
                if cmd == "resume":
                    st.resume()
                    print("resumed")
                elif cmd == "status":
                    print("paired=%s paused=%s" % (st.paired, st.paused))
                elif cmd == "quit":
                    break
        else:
            while True:
                time.sleep(3600)
    except (KeyboardInterrupt, EOFError):
        pass
    srv.shutdown()


if __name__ == "__main__":
    main()
