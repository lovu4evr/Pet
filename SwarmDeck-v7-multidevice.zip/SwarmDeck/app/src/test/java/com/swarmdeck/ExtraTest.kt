package com.swarmdeck

import org.junit.Assert.*
import org.junit.Test

class ExtraTest {
    @Test fun pdfTextExtracted() {
        val pdf = "%PDF-1.4\n1 0 obj\n<< /Length 60 >>\nstream\nBT /F1 12 Tf (Hello PDF world) Tj ET\nendstream\nendobj\n"
        assertTrue(PdfText.extract(pdf.toByteArray(Charsets.ISO_8859_1)).contains("Hello PDF world"))
    }
    @Test fun pdfTjArrayKerning() {
        val pdf = "stream\nBT [(Hel) -300 (lo)] TJ ET\nendstream\n"
        assertTrue(PdfText.extract(pdf.toByteArray(Charsets.ISO_8859_1)).contains("Hel lo"))
    }
    @Test fun mediaMarkdownByType() {
        assertEquals("![generated image](media/a.png)", Parse.mediaMarkdown("media/a.png"))
        assertEquals("[▶ video](media/a.mp4)", Parse.mediaMarkdown("media/a.mp4"))
        assertEquals("[🔊 audio](media/a.wav)", Parse.mediaMarkdown("media/a.wav"))
    }
    @Test fun ddgLiteParsed() {
        val html = "<a rel=\"nofollow\" href=\"//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fx\" class='result-link'>Example</a><td class='result-snippet'>A snippet</td>"
        val r = Parse.parseDdgLite(html)
        assertEquals("https://example.com/x", r[0].second)
    }
    @Test fun looksLikeTextRejectsGarbage() {
        assertFalse(PdfText.looksLikeText("@@##$$%%^^&&**((".repeat(40)))
    }
}
