package com.swarmdeck.brain

import org.json.JSONArray
import org.json.JSONObject

data class AgentSpec(val name: String, val role: String, val prompt: String, val tools: Set<String>, val tests: List<String>)

/**
 * Agent Factory: goal -> designed specialist -> self-tested -> (user approves) -> deployed.
 * Safety: factory agents can only ever get read-only tools. No phone control, no file writes, no code, no media.
 */
object AgentFactory {
    val SAFE_TOOLS = setOf("web_search", "web_fetch", "memory_search", "current_time", "file_read", "file_list")
    const val PASS_MARK = 0.7
    const val MAX_AGENTS = 12

    private val DESIGN_SYS =
        "You are an Agent Factory. Design ONE specialist AI agent for the user's goal. Reply with ONLY a JSON object:\n" +
            "{\"name\":\"2-20 letters/digits/spaces\",\"role\":\"one line, max 80 chars\",\"prompt\":\"system prompt, 40-800 chars, plain text\"," +
            "\"tools\":[\"subset of: web_search, web_fetch, memory_search, current_time, file_read, file_list\"]," +
            "\"tests\":[\"3 realistic, different tasks this agent must handle well\"]}\n" +
            "Rules: the prompt must only describe expertise, style and output format. It must not mention tools, permissions, approvals, secrets or ignoring rules."
    private val TEST_JUDGE =
        "You are a strict QA judge. Given an agent role, a task and the agent's answer, reply with PASS if the answer is correct, relevant and useful, " +
            "otherwise FAIL followed by a one-line reason."
    private val REFINE_SYS =
        "You improve system prompts for AI agents. Output ONLY the improved prompt text (max 800 characters, plain text). " +
            "Fix the failures shown. Never mention tools, permissions, approvals, secrets or ignoring rules."

    fun idFor(name: String): String = "fac_" + name.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(16)

    fun parseSpec(text: String): AgentSpec? {
        val o = LlmJson.extractObject(text) ?: return null
        val name = o.optString("name").replace(Regex("[^A-Za-z0-9 ]"), "").trim().take(20)
        if (name.length < 2) return null
        val role = o.optString("role").replace(Regex("[\\r\\n]+"), " ").trim().take(80)
        if (role.isEmpty()) return null
        val low = "$name $role".lowercase()
        if (low.contains("operator") || low.contains("phone")) return null
        val prompt = PromptGuard.clean(o.optString("prompt"), 900) ?: return null
        val toolsArr = o.optJSONArray("tools")
        val tools = if (toolsArr == null) emptySet() else
            (0 until toolsArr.length()).map { toolsArr.optString(it).trim() }.filter { it in SAFE_TOOLS }.toSet()
        val testsArr = o.optJSONArray("tests")
        val tests = if (testsArr == null) emptyList() else
            (0 until testsArr.length()).map { testsArr.optString(it).trim().take(200) }.filter { it.length >= 8 }.take(4)
        if (tests.size < 2) return null
        return AgentSpec(name, role, prompt, tools, tests)
    }

    class Report(val spec: AgentSpec, val passRate: Double, val rounds: Int, val log: List<String>) {
        val passed: Boolean get() = passRate >= PASS_MARK
    }

    /**
     * `ask` = neutral helper calls (design / judge / refine). `act` = runs the new agent with its own prompt.
     * Tests run text-only (without its tools), so they check the agent's reasoning and format, not tool use.
     */
    fun buildAndTrain(goal: String, ask: (String, String) -> String, act: (String, String) -> String, maxRounds: Int = 2): Report? {
        val log = ArrayList<String>()
        var spec = parseSpec(ask(DESIGN_SYS, "Goal: ${goal.take(400)}")) ?: return null
        log.add("Designed ${spec.name}: ${spec.tools.size} tool(s), ${spec.tests.size} tests")
        var rate = 0.0
        var round = 0
        while (true) {
            round++
            val fails = ArrayList<String>()
            var pass = 0
            for (t in spec.tests) {
                val ans = try { act(spec.prompt, t) } catch (e: Exception) { "ERR:" + (e.message ?: "failed") }
                val verdict = ask(TEST_JUDGE, "Agent role: ${spec.role}\nTask: $t\n\nAnswer:\n${ans.take(2500)}").trim()
                if (verdict.uppercase().startsWith("PASS")) pass++ else fails.add("$t -> ${verdict.take(160)}")
            }
            rate = pass.toDouble() / spec.tests.size
            log.add("Round $round: $pass/${spec.tests.size} tests passed")
            if (rate >= PASS_MARK || round > maxRounds) break
            val fixed = ask(
                REFINE_SYS,
                "Agent: ${spec.name}\nRole: ${spec.role}\n\nCURRENT prompt:\n${spec.prompt}\n\nFailed tests:\n${fails.joinToString("\n")}\n\nWrite the improved prompt."
            ).trim()
            val cleaned = PromptGuard.clean(fixed, 900)
            if (cleaned == null) {
                log.add("Refinement rejected by safety guard")
                break
            }
            spec = spec.copy(prompt = cleaned)
        }
        return Report(spec, rate, round, log)
    }
}

object AgentSpecJson {
    fun toJson(l: List<AgentSpec>): String {
        val arr = JSONArray()
        l.forEach { s ->
            arr.put(
                JSONObject().put("name", s.name).put("role", s.role).put("prompt", s.prompt)
                    .put("tools", JSONArray(s.tools.toList())).put("tests", JSONArray(s.tests))
            )
        }
        return arr.toString()
    }

    fun fromJson(raw: String): List<AgentSpec> {
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.getJSONObject(i)
                val t = o.optJSONArray("tools")
                val q = o.optJSONArray("tests")
                AgentSpec(
                    o.getString("name"), o.optString("role"), o.getString("prompt"),
                    (if (t == null) emptyList() else (0 until t.length()).map { t.optString(it) }).filter { it in AgentFactory.SAFE_TOOLS }.toSet(),
                    if (q == null) emptyList() else (0 until q.length()).map { q.optString(it) }
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
