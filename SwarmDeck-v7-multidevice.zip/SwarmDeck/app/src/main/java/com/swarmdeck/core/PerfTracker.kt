package com.swarmdeck.core

import android.content.Context
import com.swarmdeck.Vault
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Agent Performance Dashboard data.
 * Tracks tokens, tool calls, success rates per agent.
 */
object PerfTracker {

    private const val PREF = "swarmdeck_perf_v1"
    private const val KEY = "stats_enc"

    data class AgentStats(
        val agentId: String,
        var name: String,
        var runs: Int = 0,
        var successes: Int = 0,
        var failures: Int = 0,
        var totalTokens: Long = 0L,
        var totalToolCalls: Int = 0,
        var totalLatencyMs: Long = 0L,
        var lastUsed: Long = 0L
    ) {
        val successRate: Float get() = if (runs == 0) 0f else successes.toFloat() / runs
        val avgLatencyMs: Long get() = if (runs == 0) 0L else totalLatencyMs / runs
    }

    private val live = ConcurrentHashMap<String, AgentStats>()

    fun record(
        c: Context,
        agentId: String,
        name: String,
        success: Boolean,
        tokens: Long,
        toolCalls: Int,
        latencyMs: Long
    ) {
        val s = live.getOrPut(agentId) { AgentStats(agentId, name) }
        s.runs++
        if (success) s.successes++ else s.failures++
        s.totalTokens += tokens
        s.totalToolCalls += toolCalls
        s.totalLatencyMs += latencyMs
        s.lastUsed = System.currentTimeMillis()
        s.name = name
        persist(c)
    }

    fun all(c: Context): List<AgentStats> {
        if (live.isEmpty()) load(c)
        return live.values.sortedByDescending { it.lastUsed }
    }

    fun summary(c: Context): String {
        val stats = all(c)
        if (stats.isEmpty()) return "No agent runs recorded yet."
        return buildString {
            appendLine("### Agent Performance")
            stats.take(10).forEach { s ->
                appendLine("- **${s.name}**: ${s.runs} runs, ${(s.successRate * 100).toInt()}% success, ${s.totalTokens} tokens, ${s.totalToolCalls} tools, avg ${s.avgLatencyMs}ms")
            }
        }
    }

    private fun persist(c: Context) {
        val arr = JSONArray()
        live.values.forEach { s ->
            arr.put(JSONObject().apply {
                put("agentId", s.agentId)
                put("name", s.name)
                put("runs", s.runs)
                put("successes", s.successes)
                put("failures", s.failures)
                put("totalTokens", s.totalTokens)
                put("totalToolCalls", s.totalToolCalls)
                put("totalLatencyMs", s.totalLatencyMs)
                put("lastUsed", s.lastUsed)
            })
        }
        prefs(c).edit().putString(KEY, Vault.enc(arr.toString())).apply()
    }

    private fun load(c: Context) {
        val raw = Vault.dec(prefs(c).getString(KEY, "") ?: "")
        if (raw.isBlank()) return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val s = AgentStats(
                    agentId = o.getString("agentId"),
                    name = o.optString("name", o.getString("agentId")),
                    runs = o.optInt("runs"),
                    successes = o.optInt("successes"),
                    failures = o.optInt("failures"),
                    totalTokens = o.optLong("totalTokens"),
                    totalToolCalls = o.optInt("totalToolCalls"),
                    totalLatencyMs = o.optLong("totalLatencyMs"),
                    lastUsed = o.optLong("lastUsed")
                )
                live[s.agentId] = s
            }
        } catch (_: Exception) {}
    }

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
