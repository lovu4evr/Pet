package com.swarmdeck.core

import android.content.Context
import com.swarmdeck.memory.GoalStore
import com.swarmdeck.memory.LocalRag
import com.swarmdeck.mission.MissionEngine
import com.swarmdeck.security.AppLock

/**
 * Builds enriched system / user context for Brain.
 * Call this before every major agent run.
 */
object ContextBuilder {

    /**
     * Returns extra system context (goals + active mission + settings).
     * Append this to the agent system prompt.
     */
    fun systemExtras(c: Context): String {
        return buildString {
            val goals = GoalStore.contextForAgents(c)
            if (goals.isNotBlank()) {
                appendLine(goals)
                appendLine()
            }

            val missions = MissionEngine.list(c).filter {
                it.status == MissionStatus.RUNNING || it.status == MissionStatus.WAITING_APPROVAL
            }
            if (missions.isNotEmpty()) {
                appendLine("### Active Missions")
                missions.take(3).forEach { m ->
                    appendLine("- ${m.objective} [${m.status}] (${(MissionEngine.progress(m) * 100).toInt()}%)")
                    MissionEngine.currentCheckpoint(m)?.let { cp ->
                        appendLine("  Current step: ${cp.title} (${cp.status})")
                    }
                }
                appendLine()
            }

            val s = AppLock.settings(c)
            if (s.paranoidMode) {
                appendLine("PARANOID MODE is ON. Ask for confirmation before any shell, phone, file write, or destructive action.")
                appendLine()
            }
        }.trim()
    }

    /**
     * RAG context for a user query. Returns empty if nothing relevant.
     */
    fun ragContext(c: Context, query: String): String {
        return LocalRag.contextForQuery(c, query, topK = 5)
    }

    /**
     * Full enriched user message (original + RAG).
     */
    fun enrichUserMessage(c: Context, userText: String): String {
        val rag = ragContext(c, userText)
        return if (rag.isBlank()) userText
        else "$userText\n\n$rag"
    }
}
