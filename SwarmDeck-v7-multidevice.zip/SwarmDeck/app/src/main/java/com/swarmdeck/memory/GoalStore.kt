package com.swarmdeck.memory

import android.content.Context
import com.swarmdeck.Vault
import com.swarmdeck.core.Goal
import com.swarmdeck.core.GoalStatus
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Long-term Goals + Persistent Agent Memory for SwarmDeck 5.3
 * Stored encrypted via Vault.
 */
object GoalStore {

    private const val PREF = "swarmdeck_goals_v1"
    private const val KEY_GOALS = "goals_enc"

    fun list(c: Context): List<Goal> {
        val raw = Vault.dec(prefs(c).getString(KEY_GOALS, "") ?: "")
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                try { parseGoal(arr.getJSONObject(i)) } catch (_: Exception) { null }
            }.sortedWith(compareBy({ it.status != GoalStatus.ACTIVE }, { it.priority }, { -it.updatedAt }))
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(c: Context, goal: Goal) {
        val all = list(c).toMutableList()
        val idx = all.indexOfFirst { it.id == goal.id }
        val updated = goal.copy(updatedAt = System.currentTimeMillis())
        if (idx >= 0) all[idx] = updated else all.add(0, updated)
        persist(c, all)
    }

    fun delete(c: Context, id: String) {
        persist(c, list(c).filter { it.id != id })
    }

    fun updateProgress(c: Context, id: String, progress: Float, status: GoalStatus? = null) {
        val all = list(c).toMutableList()
        val idx = all.indexOfFirst { it.id == id }
        if (idx < 0) return
        val g = all[idx]
        all[idx] = g.copy(
            progress = progress.coerceIn(0f, 1f),
            status = status ?: g.status,
            updatedAt = System.currentTimeMillis()
        )
        persist(c, all)
    }

    fun activeGoals(c: Context): List<Goal> = list(c).filter { it.status == GoalStatus.ACTIVE }

    /** Returns a compact context string for injection into agent system prompts */
    fun contextForAgents(c: Context, max: Int = 8): String {
        val goals = activeGoals(c).take(max)
        if (goals.isEmpty()) return ""
        return buildString {
            appendLine("### Active Long-term Goals")
            goals.forEach { g ->
                append("- [${g.priority}] ${g.title}")
                if (g.progress > 0f) append(" (${(g.progress * 100).toInt()}%)")
                if (g.description.isNotBlank()) append(" — ${g.description.take(120)}")
                appendLine()
            }
        }
    }

    fun create(
        c: Context,
        title: String,
        description: String = "",
        priority: Int = 3,
        tags: List<String> = emptyList(),
        dueAt: Long? = null
    ): Goal {
        val g = Goal(
            id = UUID.randomUUID().toString(),
            title = title.trim(),
            description = description.trim(),
            priority = priority.coerceIn(1, 5),
            tags = tags,
            dueAt = dueAt
        )
        save(c, g)
        return g
    }

    private fun persist(c: Context, goals: List<Goal>) {
        val arr = JSONArray()
        goals.forEach { arr.put(toJson(it)) }
        prefs(c).edit().putString(KEY_GOALS, Vault.enc(arr.toString())).apply()
    }

    private fun toJson(g: Goal) = JSONObject().apply {
        put("id", g.id)
        put("title", g.title)
        put("description", g.description)
        put("status", g.status.name)
        put("priority", g.priority)
        put("createdAt", g.createdAt)
        put("updatedAt", g.updatedAt)
        put("dueAt", g.dueAt ?: JSONObject.NULL)
        put("tags", JSONArray(g.tags))
        put("progress", g.progress.toDouble())
        put("linkedMissionIds", JSONArray(g.linkedMissionIds))
    }

    private fun parseGoal(o: JSONObject) = Goal(
        id = o.getString("id"),
        title = o.getString("title"),
        description = o.optString("description", ""),
        status = try { GoalStatus.valueOf(o.optString("status", "ACTIVE")) } catch (_: Exception) { GoalStatus.ACTIVE },
        priority = o.optInt("priority", 3),
        createdAt = o.optLong("createdAt", System.currentTimeMillis()),
        updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
        dueAt = if (o.isNull("dueAt")) null else o.optLong("dueAt"),
        tags = o.optJSONArray("tags")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList(),
        progress = o.optDouble("progress", 0.0).toFloat(),
        linkedMissionIds = o.optJSONArray("linkedMissionIds")?.let { a ->
            (0 until a.length()).map { a.getString(it) }
        } ?: emptyList()
    )

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
