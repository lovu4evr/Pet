package com.swarmdeck.brain

import org.json.JSONArray
import org.json.JSONObject

/**
 * Safety gate for every model-written prompt (evolved or factory-built).
 * Prompts can only change an agent's *style and focus* - never its tools, approvals or rules.
 */
object PromptGuard {
    private val BAD = listOf(
        "ignore previous", "ignore all", "ignore the", "disregard", "jailbreak", "system prompt",
        "api key", "apikey", "password", "sudo", "exfiltrat", "tool_call", "action:",
        "bypass", "override", "without asking", "without confirmation", "without approval",
        "skip approval", "skip confirm", "auto-approve", "always approve", "disable safety", "unrestricted"
    )

    fun clean(raw: String, maxLen: Int = 700): String? {
        val p = raw.replace(Regex("[\\r\\t]+"), " ").replace(Regex("\\n{3,}"), "\n\n").trim().trim('"').trim()
        if (p.length < 30 || p.length > maxLen) return null
        val low = p.lowercase()
        if (BAD.any { low.contains(it) }) return null
        return p
    }
}

data class PromptVersion(val version: Int, val prompt: String, val reason: String, val createdAt: Long)

/** Evolution state of one agent. `active == null` means the built-in prompt is in use. */
data class AgentEvo(
    val agentId: String,
    val active: PromptVersion? = null,
    val trial: PromptVersion? = null,
    val history: List<PromptVersion> = emptyList(),
    val baseScores: List<Int> = emptyList(),
    val trialScores: List<Int> = emptyList(),
    val cooldownUntil: Long = 0L,
    val nextVersion: Int = 1
)

enum class Decision { PROMOTE, REJECT, WAIT }

/** Pure A/B logic: candidate prompts must beat the current one on real peer scores before they are kept. */
object Evo {
    const val WINDOW = 30
    const val MIN_RUNS = 8
    const val WEAK_BELOW = 7.5
    const val MIN_PER_ARM = 6
    const val MARGIN = 0.5
    const val MAX_TRIAL_RUNS = 16
    const val COOLDOWN_MS = 3L * 24 * 3600 * 1000

    fun mean(l: List<Int>): Double = if (l.isEmpty()) 0.0 else l.sum().toDouble() / l.size

    /** arm 0 = current prompt, arm 1 = trial prompt (only while a trial is running). */
    fun promptFor(s: AgentEvo?, builtin: String, arm: Int): String {
        if (s == null) return builtin
        val t = s.trial
        if (arm == 1 && t != null) return t.prompt
        return s.active?.prompt ?: builtin
    }

    fun record(s: AgentEvo, arm: Int, score: Int): AgentEvo {
        val sc = score.coerceIn(0, 10)
        return if (s.trial != null && arm == 1) s.copy(trialScores = (s.trialScores + sc).takeLast(WINDOW))
        else s.copy(baseScores = (s.baseScores + sc).takeLast(WINDOW))
    }

    fun needsEvolution(s: AgentEvo, now: Long, minRuns: Int = MIN_RUNS): Boolean =
        s.trial == null && now >= s.cooldownUntil && s.baseScores.size >= minRuns && mean(s.baseScores) < WEAK_BELOW

    fun startTrial(s: AgentEvo, prompt: String, reason: String, now: Long): AgentEvo =
        s.copy(
            trial = PromptVersion(s.nextVersion, prompt, reason, now),
            nextVersion = s.nextVersion + 1,
            trialScores = emptyList(),
            baseScores = emptyList()
        )

    fun decide(s: AgentEvo): Decision {
        if (s.trial == null) return Decision.WAIT
        // Early stop: a clearly bad candidate is pulled quickly.
        if (s.trialScores.size >= 3 && mean(s.trialScores) < 4.0) return Decision.REJECT
        if (s.trialScores.size < MIN_PER_ARM || s.baseScores.size < MIN_PER_ARM) {
            return if (s.trialScores.size + s.baseScores.size >= MAX_TRIAL_RUNS) Decision.REJECT else Decision.WAIT
        }
        val delta = mean(s.trialScores) - mean(s.baseScores)
        return if (delta >= MARGIN) Decision.PROMOTE else Decision.REJECT
    }

    fun apply(s: AgentEvo, d: Decision, now: Long): AgentEvo = when (d) {
        Decision.WAIT -> s
        Decision.PROMOTE -> {
            val prev = s.active ?: PromptVersion(0, "", "built-in", 0L)
            s.copy(
                active = s.trial,
                trial = null,
                history = (s.history + prev).takeLast(10),
                baseScores = emptyList(),
                trialScores = emptyList()
            )
        }
        Decision.REJECT -> s.copy(
            trial = null,
            trialScores = emptyList(),
            baseScores = emptyList(),
            cooldownUntil = now + COOLDOWN_MS
        )
    }

    /** One-step undo: back to the previous prompt (or the built-in one). Also cancels a running trial. */
    fun rollback(s: AgentEvo): AgentEvo {
        val prev = s.history.lastOrNull()
        return s.copy(
            active = if (prev == null || prev.version == 0) null else prev,
            history = s.history.dropLast(1),
            trial = null,
            baseScores = emptyList(),
            trialScores = emptyList()
        )
    }
}

object EvoJson {
    private fun pv(v: PromptVersion): JSONObject =
        JSONObject().put("v", v.version).put("p", v.prompt).put("r", v.reason).put("t", v.createdAt)

    private fun pvFrom(o: JSONObject?): PromptVersion? =
        if (o == null) null else PromptVersion(o.optInt("v"), o.optString("p"), o.optString("r"), o.optLong("t"))

    private fun ints(a: List<Int>): JSONArray {
        val arr = JSONArray()
        a.forEach { arr.put(it) }
        return arr
    }

    private fun intsFrom(a: JSONArray?): List<Int> =
        if (a == null) emptyList() else (0 until a.length()).map { a.optInt(it) }

    fun toJson(m: Map<String, AgentEvo>): String {
        val arr = JSONArray()
        m.values.forEach { s ->
            val o = JSONObject()
            o.put("id", s.agentId)
            s.active?.let { o.put("active", pv(it)) }
            s.trial?.let { o.put("trial", pv(it)) }
            val h = JSONArray()
            s.history.forEach { h.put(pv(it)) }
            o.put("history", h)
            o.put("base", ints(s.baseScores))
            o.put("cand", ints(s.trialScores))
            o.put("cool", s.cooldownUntil)
            o.put("next", s.nextVersion)
            arr.put(o)
        }
        return arr.toString()
    }

    fun fromJson(raw: String): Map<String, AgentEvo> {
        if (raw.isBlank()) return emptyMap()
        return try {
            val arr = JSONArray(raw)
            val out = LinkedHashMap<String, AgentEvo>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                val hist = o.optJSONArray("history")
                out[id] = AgentEvo(
                    agentId = id,
                    active = pvFrom(o.optJSONObject("active")),
                    trial = pvFrom(o.optJSONObject("trial")),
                    history = if (hist == null) emptyList() else (0 until hist.length()).mapNotNull { pvFrom(hist.optJSONObject(it)) },
                    baseScores = intsFrom(o.optJSONArray("base")),
                    trialScores = intsFrom(o.optJSONArray("cand")),
                    cooldownUntil = o.optLong("cool"),
                    nextVersion = o.optInt("next", 1)
                )
            }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    }
}
