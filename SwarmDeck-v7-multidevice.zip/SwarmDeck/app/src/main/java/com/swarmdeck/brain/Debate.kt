package com.swarmdeck.brain

/**
 * Prompt-rewrite debate: Proposer drafts -> Critic attacks -> Proposer revises -> Judge says REPLACE/KEEP.
 * `ask(system, user)` is injected so this stays pure and unit-testable.
 */
object Debate {
    class Result(val candidate: String?, val transcript: List<String>)

    private val PROPOSER =
        "You improve system prompts for AI agents. Output ONLY the new prompt text (max 600 characters, no quotes, no markdown, no commentary). " +
            "Keep the agent's purpose. Never add tool use, permissions, approvals, secrets, or any instruction about ignoring rules."
    private val CRITIC =
        "You are a ruthless prompt critic. List at most 3 concrete weaknesses of the PROPOSED prompt compared to the CURRENT one " +
            "(vague, risky, too long, drops the purpose, grants powers). If it is clearly better and safe, reply exactly: NO MAJOR ISSUES."
    private val JUDGE =
        "You judge two system prompts for the same agent. Reply with exactly one word: REPLACE if the PROPOSED prompt is clearly better and safe, otherwise KEEP."

    fun improvePrompt(ask: (String, String) -> String, name: String, role: String, current: String, weakNotes: String): Result {
        val log = ArrayList<String>()
        val first = ask(
            PROPOSER,
            "Agent: $name\nRole: $role\nWeak spots seen in real use: $weakNotes\n\nCURRENT prompt:\n$current\n\nWrite an improved prompt."
        ).trim()
        log.add("Proposer: " + first.take(160))

        val critique = ask(CRITIC, "CURRENT:\n$current\n\nPROPOSED:\n$first")
        log.add("Critic: " + critique.take(160))

        val revised = if (critique.contains("NO MAJOR ISSUES", true)) first else ask(
            PROPOSER,
            "Agent: $name\nRole: $role\n\nCURRENT prompt:\n$current\n\nYour previous proposal:\n$first\n\n" +
                "Critic feedback:\n$critique\n\nWrite the final improved prompt."
        ).trim()

        val verdict = ask(JUDGE, "CURRENT:\n$current\n\nPROPOSED:\n$revised").trim()
        log.add("Judge: " + verdict.take(40))
        if (!verdict.uppercase().startsWith("REPLACE")) return Result(null, log)

        val cleaned = PromptGuard.clean(revised, 700)
        if (cleaned == null) {
            log.add("Guard: rejected (unsafe or invalid)")
            return Result(null, log)
        }
        if (cleaned == current.trim()) return Result(null, log)
        return Result(cleaned, log)
    }
}
