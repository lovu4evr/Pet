package com.swarmdeck.guard

/** Finds things that must never leave the device or be typed by an agent: cards, keys, passwords, OTPs, IDs. Pure JVM. */
object SecretScan {
    data class Hit(val kind: String, val start: Int, val end: Int)

    private val CARD = Regex("(?<!\\d)(?:\\d[ -]?){12,18}\\d(?!\\d)")
    private val TOKEN = Regex("[A-Za-z0-9_\\-]{40,}")
    private val RULES: List<Pair<String, Regex>> = listOf(
        "AWS key" to Regex("AKIA[0-9A-Z]{16}"),
        "API key" to Regex("sk-[A-Za-z0-9_\\-]{20,}"),
        "GitHub token" to Regex("gh[pousr]_[A-Za-z0-9]{30,}"),
        "JWT" to Regex("eyJ[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,}"),
        "private key" to Regex("-----BEGIN [A-Z ]*PRIVATE KEY-----"),
        "password" to Regex("(?i)\\b(?:password|passwd|pwd|passcode)\\s*(?:is|=|:)\\s*\\S{4,}"),
        "one-time code" to Regex("(?i)\\b(?:otp|cvv|cvc|verification code|one[- ]time (?:code|password))\\D{0,12}\\d{3,8}"),
        "SSN-like number" to Regex("(?<!\\d)\\d{3}-\\d{2}-\\d{4}(?!\\d)"),
        "12-digit ID" to Regex("(?<!\\d)(?<!\\d\\s)\\d{4}\\s\\d{4}\\s\\d{4}(?![\\s-]?\\d)")
    )

    fun luhn(d: String): Boolean {
        if (d.isEmpty()) return false
        var sum = 0
        var alt = false
        for (i in d.length - 1 downTo 0) {
            var n = d[i] - '0'
            if (alt) {
                n *= 2
                if (n > 9) n -= 9
            }
            sum += n
            alt = !alt
        }
        return sum % 10 == 0
    }

    fun find(text: String): List<Hit> {
        val hits = ArrayList<Hit>()
        for (m in CARD.findAll(text)) {
            val digits = m.value.filter { it.isDigit() }
            if (digits.length in 13..19 && luhn(digits)) hits.add(Hit("card number", m.range.first, m.range.last + 1))
        }
        for ((kind, re) in RULES) {
            for (m in re.findAll(text)) hits.add(Hit(kind, m.range.first, m.range.last + 1))
        }
        for (m in TOKEN.findAll(text)) {
            val v = m.value
            if (v.any { it.isDigit() } && v.any { it.isUpperCase() } && v.any { it.isLowerCase() }) {
                hits.add(Hit("long secret-looking token", m.range.first, m.range.last + 1))
            }
        }
        return hits.sortedWith(compareBy({ it.start }, { -(it.end - it.start) }))
    }

    fun kinds(text: String): String = find(text).map { it.kind }.distinct().joinToString(", ")

    fun redact(text: String): String {
        val hits = find(text)
        if (hits.isEmpty()) return text
        val sb = StringBuilder()
        var pos = 0
        for (h in hits) {
            if (h.start < pos) continue
            sb.append(text, pos, h.start)
            sb.append("[REDACTED:").append(h.kind).append("]")
            pos = h.end
        }
        sb.append(text, pos, text.length)
        return sb.toString()
    }
}
