package com.swarmdeck.device

import org.json.JSONObject
import java.io.IOException

data class DeviceResult(val ok: Boolean, val data: JSONObject?, val error: String)

/** Talks to swarmdeck_companion.py over the local network (raw socket, see MiniHttp). Every request is signed. Pure JVM. */
object DeviceClient {
    private const val CONNECT_MS = 4000
    private const val MAX_REPLY = 3_000_000

    /** Public, unauthenticated: name, OS, pairing salt and whether it is already paired. */
    fun info(host: String, port: Int): JSONObject {
        if (!DeviceRules.isPrivateHost(host)) throw IOException("refusing to contact a non-local address")
        val r = MiniHttp.request(host, port, "GET", "/info", emptyMap(), null, CONNECT_MS, 6000, 20_000)
        if (r.status != 200) throw IOException("HTTP " + r.status)
        return JSONObject(String(r.body, Charsets.UTF_8))
    }

    private fun signedPost(d: PairedDevice, path: String, body: ByteArray, readMs: Int): DeviceResult {
        if (!DeviceRules.isPrivateHost(d.host)) return DeviceResult(false, null, "refusing to contact a non-local address")
        val ts = System.currentTimeMillis() / 1000
        val nonce = DeviceCrypto.newNonce()
        val sig = DeviceCrypto.sign(DeviceCrypto.fromHex(d.keyHex), ts, nonce, body)
        val headers = mapOf("Content-Type" to "application/json", "X-Ts" to ts.toString(), "X-Nonce" to nonce, "X-Sig" to sig)
        val r = try {
            MiniHttp.request(d.host, d.port, "POST", path, headers, body, CONNECT_MS, readMs, MAX_REPLY)
        } catch (e: IOException) {
            return DeviceResult(false, null, "cannot reach ${d.name}: ${e.message}")
        }
        val o = try {
            JSONObject(String(r.body, Charsets.UTF_8))
        } catch (_: Exception) {
            return DeviceResult(false, null, "unreadable reply from ${d.name} (HTTP ${r.status})")
        }
        return if (o.optBoolean("ok")) DeviceResult(true, o.optJSONObject("data") ?: JSONObject(), "")
        else DeviceResult(false, null, o.optString("error", "HTTP " + r.status))
    }

    fun call(d: PairedDevice, action: String, args: JSONObject, readMs: Int = 20_000): DeviceResult {
        val body = JSONObject().put("action", action).put("args", args).toString().toByteArray(Charsets.UTF_8)
        return signedPost(d, "/act", body, readMs)
    }

    /** Pauses the companion until the user types `resume` on the computer. */
    fun halt(d: PairedDevice): DeviceResult = signedPost(d, "/halt", "{}".toByteArray(Charsets.UTF_8), 6000)
}
