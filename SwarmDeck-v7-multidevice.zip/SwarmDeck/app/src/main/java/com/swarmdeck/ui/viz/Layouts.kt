package com.swarmdeck.ui.viz

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class P2(val x: Float, val y: Float)

/** Orbiting "agent satellites" around the orb: two tilted rings that turn in opposite directions. Pure math. */
object SwarmLayout {
    data class Sat(val x: Float, val y: Float, val depth: Float)

    fun satellites(n: Int, t: Float, r: Float): List<Sat> = (0 until n).map { i ->
        val ring = i % 2
        val base = (2.0 * PI * i / max(n, 1)).toFloat()
        val speed = if (ring == 0) 0.35f else -0.22f
        val a = base + t * speed
        val rr = r * (if (ring == 0) 1f else 0.72f)
        Sat(cos(a) * rr, sin(a) * rr * 0.55f, (sin(a) + 1f) / 2f)
    }
}

/** Fruchterman-Reingold force layout, deterministic for a given seed. Positions stay inside [pad, w-pad] x [pad, h-pad]. */
object ForceLayout {
    fun layout(
        ids: List<String>,
        edges: List<Pair<String, String>>,
        w: Float,
        h: Float,
        iterations: Int = 120,
        seed: Long = 7L,
        pad: Float = 24f
    ): Map<String, P2> {
        val n = ids.size
        if (n == 0) return emptyMap()
        val rnd = java.util.Random(seed)
        val idx = HashMap<String, Int>()
        ids.forEachIndexed { i, s -> idx[s] = i }
        val px = FloatArray(n)
        val py = FloatArray(n)
        val cx = w / 2f
        val cy = h / 2f
        val rad = min(w, h) * 0.35f
        for (i in 0 until n) {
            val a = (2.0 * PI * i / n).toFloat()
            px[i] = cx + cos(a) * rad + (rnd.nextFloat() - 0.5f) * 8f
            py[i] = cy + sin(a) * rad + (rnd.nextFloat() - 0.5f) * 8f
        }
        if (n == 1) return mapOf(ids[0] to P2(cx, cy))
        val es = edges.mapNotNull { (a, b) ->
            val i = idx[a]
            val j = idx[b]
            if (i != null && j != null && i != j) i to j else null
        }
        val k = min(sqrt((w * h) / n) * 0.7f, 140f)
        var temp = min(w, h) / 6f
        val dx = FloatArray(n)
        val dy = FloatArray(n)
        for (iter in 0 until iterations) {
            java.util.Arrays.fill(dx, 0f)
            java.util.Arrays.fill(dy, 0f)
            for (i in 0 until n) {
                for (j in i + 1 until n) {
                    var ux = px[i] - px[j]
                    var uy = py[i] - py[j]
                    var d = sqrt(ux * ux + uy * uy)
                    if (d < 0.01f) {
                        ux = (rnd.nextFloat() - 0.5f)
                        uy = (rnd.nextFloat() - 0.5f)
                        d = 0.5f
                    }
                    val f = k * k / d
                    dx[i] += ux / d * f
                    dy[i] += uy / d * f
                    dx[j] -= ux / d * f
                    dy[j] -= uy / d * f
                }
            }
            for ((i, j) in es) {
                val ux = px[i] - px[j]
                val uy = py[i] - py[j]
                val d = max(sqrt(ux * ux + uy * uy), 0.01f)
                val f = d * d / k
                dx[i] -= ux / d * f
                dy[i] -= uy / d * f
                dx[j] += ux / d * f
                dy[j] += uy / d * f
            }
            for (i in 0 until n) {
                // gentle pull to the center keeps disconnected nodes on screen
                dx[i] += (cx - px[i]) * 0.08f
                dy[i] += (cy - py[i]) * 0.08f
                val d = max(sqrt(dx[i] * dx[i] + dy[i] * dy[i]), 0.01f)
                val m = min(d, temp)
                px[i] = (px[i] + dx[i] / d * m).coerceIn(pad, w - pad)
                py[i] = (py[i] + dy[i] / d * m).coerceIn(pad, h - pad)
            }
            temp *= 0.97f
        }
        return ids.mapIndexed { i, s -> s to P2(px[i], py[i]) }.toMap()
    }
}

/** Game-style mission progress: node states + an XP-like percentage. */
object TimelineModel {
    const val PENDING = 0
    const val ACTIVE = 1
    const val DONE = 2
    const val FAILED = 3

    /** Statuses are the mission engine's strings (PENDING / RUNNING / DONE / FAILED ...). If running and nothing is marked active, the first unfinished step is active. */
    fun states(statuses: List<String>, running: Boolean): List<Int> {
        val base = statuses.map {
            when (it.uppercase()) {
                "DONE", "COMPLETED" -> DONE
                "RUNNING", "ACTIVE", "DOING", "IN_PROGRESS" -> ACTIVE
                "FAILED", "ERROR" -> FAILED
                else -> PENDING
            }
        }.toMutableList()
        if (running && base.none { it == ACTIVE }) {
            val i = base.indexOfFirst { it == PENDING }
            if (i >= 0) base[i] = ACTIVE
        }
        return base
    }

    fun progress(states: List<Int>): Float {
        if (states.isEmpty()) return 0f
        val done = states.count { it == DONE }
        val active = states.count { it == ACTIVE }
        return ((done + 0.5f * active) / states.size).coerceIn(0f, 1f)
    }

    fun xp(states: List<Int>): Int = (progress(states) * 100f).toInt()
}
