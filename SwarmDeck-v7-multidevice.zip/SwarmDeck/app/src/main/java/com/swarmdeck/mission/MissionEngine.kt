package com.swarmdeck.mission

import android.content.Context
import com.swarmdeck.Vault
import com.swarmdeck.core.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Multi-step Mission Planner with Checkpoints + Approval gates.
 * SwarmDeck 5.3
 */
object MissionEngine {

    private const val PREF = "swarmdeck_missions_v2"
    private const val KEY = "missions_enc"

    private val active = ConcurrentHashMap<String, MissionV2>()

    fun list(c: Context): List<MissionV2> {
        val raw = Vault.dec(prefs(c).getString(KEY, "") ?: "")
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull {
                try { parse(arr.getJSONObject(it)) } catch (_: Exception) { null }
            }.sortedByDescending { it.updatedAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun get(c: Context, id: String): MissionV2? =
        active[id] ?: list(c).firstOrNull { it.id == id }?.also { active[id] = it }

    fun create(
        c: Context,
        objective: String,
        checkpoints: List<Pair<String, Boolean>> = emptyList(), // title to requiresApproval
        goalId: String? = null,
        agentIds: List<String> = emptyList()
    ): MissionV2 {
        val cps = checkpoints.mapIndexed { i, (title, needsApproval) ->
            MissionCheckpoint(
                id = UUID.randomUUID().toString(),
                title = title,
                requiresApproval = needsApproval || i == checkpoints.lastIndex // last one often needs approval
            )
        }
        val m = MissionV2(
            id = UUID.randomUUID().toString(),
            objective = objective.trim(),
            checkpoints = cps,
            status = MissionStatus.PLANNING,
            goalId = goalId,
            agentIds = agentIds
        )
        save(c, m)
        return m
    }

    /** Auto-generate simple checkpoints from objective using heuristics (can be improved by LLM later) */
    fun createSmart(c: Context, objective: String, goalId: String? = null): MissionV2 {
        val steps = heuristicPlan(objective)
        return create(c, objective, steps, goalId)
    }

    private fun heuristicPlan(objective: String): List<Pair<String, Boolean>> {
        val lower = objective.lowercase()
        val plan = mutableListOf<Pair<String, Boolean>>()
        plan += "Understand the objective & gather requirements" to false
        if (lower.contains("research") || lower.contains("find") || lower.contains("search")) {
            plan += "Search & collect information" to false
            plan += "Analyze & synthesize findings" to false
        }
        if (lower.contains("code") || lower.contains("build") || lower.contains("implement")) {
            plan += "Design approach" to false
            plan += "Implement solution" to false
            plan += "Test & verify" to true
        }
        if (lower.contains("write") || lower.contains("report") || lower.contains("summary")) {
            plan += "Draft content" to false
            plan += "Review & refine" to true
        }
        plan += "Final delivery & summary" to true
        return plan.distinctBy { it.first }
    }

    fun start(c: Context, id: String): MissionV2? {
        val m = get(c, id) ?: return null
        val updated = m.copy(status = MissionStatus.RUNNING, updatedAt = System.currentTimeMillis())
        save(c, updated)
        return updated
    }

    fun advanceCheckpoint(c: Context, missionId: String, checkpointId: String, result: String, success: Boolean): MissionV2? {
        val m = get(c, missionId) ?: return null
        val cps = m.checkpoints.toMutableList()
        val idx = cps.indexOfFirst { it.id == checkpointId }
        if (idx < 0) return m

        val now = System.currentTimeMillis()
        cps[idx] = cps[idx].copy(
            status = if (success) CheckpointStatus.COMPLETED else CheckpointStatus.FAILED,
            result = result,
            completedAt = now
        )

        // Find next pending
        val nextIdx = cps.indexOfFirst { it.status == CheckpointStatus.PENDING }
        val newStatus = when {
            cps.all { it.status == CheckpointStatus.COMPLETED } -> MissionStatus.COMPLETED
            cps.any { it.status == CheckpointStatus.FAILED } && nextIdx < 0 -> MissionStatus.FAILED
            nextIdx >= 0 && cps[nextIdx].requiresApproval -> MissionStatus.WAITING_APPROVAL
            else -> MissionStatus.RUNNING
        }

        if (nextIdx >= 0 && newStatus == MissionStatus.RUNNING) {
            cps[nextIdx] = cps[nextIdx].copy(status = CheckpointStatus.RUNNING, startedAt = now)
        }

        val updated = m.copy(checkpoints = cps, status = newStatus, updatedAt = now)
        save(c, updated)
        return updated
    }

    fun approveCheckpoint(c: Context, missionId: String, checkpointId: String): MissionV2? {
        val m = get(c, missionId) ?: return null
        val cps = m.checkpoints.toMutableList()
        val idx = cps.indexOfFirst { it.id == checkpointId }
        if (idx < 0) return m
        cps[idx] = cps[idx].copy(status = CheckpointStatus.RUNNING, startedAt = System.currentTimeMillis())
        val updated = m.copy(checkpoints = cps, status = MissionStatus.RUNNING, updatedAt = System.currentTimeMillis())
        save(c, updated)
        return updated
    }

    fun pause(c: Context, id: String) = updateStatus(c, id, MissionStatus.PAUSED)
    fun resume(c: Context, id: String) = updateStatus(c, id, MissionStatus.RUNNING)
    fun cancel(c: Context, id: String) = updateStatus(c, id, MissionStatus.CANCELLED)

    private fun updateStatus(c: Context, id: String, status: MissionStatus): MissionV2? {
        val m = get(c, id) ?: return null
        val updated = m.copy(status = status, updatedAt = System.currentTimeMillis())
        save(c, updated)
        return updated
    }

    fun currentCheckpoint(m: MissionV2): MissionCheckpoint? =
        m.checkpoints.firstOrNull { it.status == CheckpointStatus.RUNNING || it.status == CheckpointStatus.WAITING_APPROVAL }
            ?: m.checkpoints.firstOrNull { it.status == CheckpointStatus.PENDING }

    fun progress(m: MissionV2): Float {
        if (m.checkpoints.isEmpty()) return 0f
        val done = m.checkpoints.count { it.status == CheckpointStatus.COMPLETED }
        return done.toFloat() / m.checkpoints.size
    }

    private fun save(c: Context, m: MissionV2) {
        active[m.id] = m
        val all = list(c).filter { it.id != m.id }.toMutableList()
        all.add(0, m)
        val arr = JSONArray()
        all.take(50).forEach { arr.put(toJson(it)) } // keep last 50
        prefs(c).edit().putString(KEY, Vault.enc(arr.toString())).apply()
    }

    private fun toJson(m: MissionV2) = JSONObject().apply {
        put("id", m.id)
        put("objective", m.objective)
        put("status", m.status.name)
        put("createdAt", m.createdAt)
        put("updatedAt", m.updatedAt)
        put("goalId", m.goalId ?: JSONObject.NULL)
        put("agentIds", JSONArray(m.agentIds))
        val cps = JSONArray()
        m.checkpoints.forEach { cp ->
            cps.put(JSONObject().apply {
                put("id", cp.id)
                put("title", cp.title)
                put("description", cp.description)
                put("status", cp.status.name)
                put("requiresApproval", cp.requiresApproval)
                put("result", cp.result)
                put("startedAt", cp.startedAt ?: JSONObject.NULL)
                put("completedAt", cp.completedAt ?: JSONObject.NULL)
            })
        }
        put("checkpoints", cps)
    }

    private fun parse(o: JSONObject): MissionV2 {
        val cpsArr = o.optJSONArray("checkpoints") ?: JSONArray()
        val cps = (0 until cpsArr.length()).map { i ->
            val c = cpsArr.getJSONObject(i)
            MissionCheckpoint(
                id = c.getString("id"),
                title = c.getString("title"),
                description = c.optString("description", ""),
                status = try { CheckpointStatus.valueOf(c.optString("status", "PENDING")) } catch (_: Exception) { CheckpointStatus.PENDING },
                requiresApproval = c.optBoolean("requiresApproval", false),
                result = c.optString("result", ""),
                startedAt = if (c.isNull("startedAt")) null else c.optLong("startedAt"),
                completedAt = if (c.isNull("completedAt")) null else c.optLong("completedAt")
            )
        }
        return MissionV2(
            id = o.getString("id"),
            objective = o.getString("objective"),
            checkpoints = cps,
            status = try { MissionStatus.valueOf(o.optString("status", "PLANNING")) } catch (_: Exception) { MissionStatus.PLANNING },
            createdAt = o.optLong("createdAt"),
            updatedAt = o.optLong("updatedAt"),
            goalId = if (o.isNull("goalId")) null else o.optString("goalId"),
            agentIds = o.optJSONArray("agentIds")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
        )
    }

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
