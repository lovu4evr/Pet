package com.swarmdeck.memgraph

import android.content.Context
import com.swarmdeck.Audit
import com.swarmdeck.Bus
import com.swarmdeck.Run
import com.swarmdeck.Turn
import com.swarmdeck.guard.SecretScan

/**
 * Chat commands for the memory graph / personal OS:
 *   decide: <title> [because <reason>]   record a decision (auto-linked to the goal it matches best)
 *   decisions | decisions: done <id> | decisions: drop <id>
 *   recall: <topic>                      graph-aware recall (matches + what is connected to them)
 *   graph                                size and top topics of your memory graph
 *   os | os: brief                       proactive briefing from your goals and open decisions
 */
object GraphCmd {
    private val CMD = Regex("^(decide|decisions?|recall|graph|os)\\s*(?::\\s*(.*))?$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    fun handle(c: Context, run: Run, q: String): Turn? {
        val m = CMD.find(q.trim()) ?: return null
        val cmd = m.groupValues[1].lowercase()
        val arg = m.groupValues[2].trim()
        val text = when {
            cmd == "decide" -> decide(c, arg)
            cmd.startsWith("decision") -> decisionsCmd(c, arg)
            cmd == "recall" -> recall(c, arg)
            cmd == "graph" -> stats(c)
            else -> brief(c)
        }
        return Turn(false, text, "", emptyList(), Bus.thinkSnapshot())
    }

    private fun decide(c: Context, arg: String): String {
        if (arg.isBlank()) return "Usage: `decide: Move to Pune because rent is lower`"
        val kinds = SecretScan.kinds(arg)
        if (kinds.isNotEmpty()) return "Not saved: the text contains $kinds. Decisions are stored in memory, which is not a password manager."
        val (title, reason) = DecisionText.split(arg)
        val (d, goal) = GraphHub.addDecision(c, title, reason)
        Audit.log(c, "decision", d.title)
        val link = if (goal != null) "\nLinked to your goal **${goal.title}**." else ""
        val why = if (reason.isNotBlank()) "\nReason: $reason" else "\nTip: add `because ...` so future-you remembers why."
        return "Decision recorded (#${d.id}): **${d.title}**$why$link"
    }

    private fun decisionsCmd(c: Context, arg: String): String {
        val low = arg.lowercase()
        if (low.startsWith("done ") || low.startsWith("drop ")) {
            val id = arg.substring(5).trim().removePrefix("#")
            val st = if (low.startsWith("done ")) "DONE" else "DROPPED"
            val d = GraphHub.setStatus(c, id, st) ?: return "No decision #$id."
            return "Decision #${d.id} marked ${st.lowercase()}."
        }
        val l = GraphHub.decisions(c).take(10)
        if (l.isEmpty()) return "No decisions yet. Record one with `decide: <what> because <why>`."
        val fmt = java.text.SimpleDateFormat("d MMM", java.util.Locale.US)
        return "### Decisions\n" + l.joinToString("\n") {
            "- #${it.id} · ${fmt.format(java.util.Date(it.ts))} · **${it.title}** [${it.status.lowercase()}]" +
                (if (it.reason.isNotBlank()) " — ${it.reason.take(80)}" else "")
        } + "\n\nClose one with `decisions: done <id>` or `decisions: drop <id>`."
    }

    private fun recall(c: Context, arg: String): String {
        if (arg.isBlank()) return "Usage: `recall: <topic>`"
        val hits = GraphQuery.recall(GraphHub.build(c), arg)
        return "### Memory graph: $arg\n" + GraphQuery.contextText(hits)
    }

    private fun stats(c: Context): String {
        val g = GraphHub.build(c)
        if (g.nodes.isEmpty()) return "Your memory graph is empty. Save facts, add goals or record decisions and it grows by itself."
        val byType = g.nodes.groupingBy { it.type }.eachCount()
        val topics = g.nodes.filter { it.type == NodeType.TOPIC }.sortedByDescending { it.weight }.take(8).joinToString(", ") { it.label }
        return "### Memory graph\n" +
            "- ${g.nodes.size} nodes, ${g.edges.size} links\n" +
            "- Facts ${byType[NodeType.FACT] ?: 0}, goals ${byType[NodeType.GOAL] ?: 0}, decisions ${byType[NodeType.DECISION] ?: 0}, topics ${byType[NodeType.TOPIC] ?: 0}\n" +
            (if (topics.isNotEmpty()) "- Top topics: $topics\n" else "") +
            "\nOpen **Memory Graph** in the menu to explore it."
    }

    private fun brief(c: Context): String {
        val s = GraphHub.suggestions(c)
        if (s.isEmpty()) return "### Briefing\nNothing needs attention right now. Your goals are on track and no decisions are waiting for review."
        return "### Briefing\n" + s.joinToString("\n") { "- ${it.title}" } +
            "\n\nOpen the Immersive view and swipe to Briefing, then tap an item to hand it to your agents."
    }
}
