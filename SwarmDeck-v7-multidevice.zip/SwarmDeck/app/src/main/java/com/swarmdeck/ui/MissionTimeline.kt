package com.swarmdeck.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.ACC2
import com.swarmdeck.CREAM
import com.swarmdeck.GOLD
import com.swarmdeck.MStep
import com.swarmdeck.MUTED
import com.swarmdeck.ui.viz.TimelineModel

/** Mission as a quest line: XP bar on top, one node per step (done = gold check, active = pulsing ring, failed = red). */
@Composable
fun MissionTimeline(steps: List<MStep>, running: Boolean, objective: String, modifier: Modifier = Modifier) {
    val states = TimelineModel.states(steps.map { it.status }, running)
    val p = TimelineModel.progress(states)
    val inf = rememberInfiniteTransition(label = "tl")
    val glow by inf.animateFloat(0.35f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
    Column(modifier.fillMaxWidth()) {
        Text(
            objective.ifBlank { "No active mission" }, color = GOLD, fontSize = 16.sp,
            fontWeight = FontWeight.Bold, maxLines = 2
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("XP " + TimelineModel.xp(states), color = CREAM, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(10.dp))
            LinearProgressIndicator(
                progress = { p },
                modifier = Modifier.weight(1f).height(8.dp).clip(CircleShape),
                color = GOLD, trackColor = Color(0x33F5B301)
            )
            Spacer(Modifier.width(10.dp))
            Text(states.count { it == TimelineModel.DONE }.toString() + "/" + states.size, color = MUTED, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
        if (steps.isEmpty()) {
            Text("Say \"mission: <your goal>\" and the plan appears here as a quest line.", color = MUTED, fontSize = 13.sp)
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.Top) {
                itemsIndexed(steps) { i, st -> TimelineRow(st, states.getOrElse(i) { TimelineModel.PENDING }, i == steps.lastIndex, glow) }
            }
        }
    }
}

@Composable
private fun TimelineRow(step: MStep, state: Int, last: Boolean, glow: Float) {
    val col = when (state) {
        TimelineModel.DONE -> GOLD
        TimelineModel.ACTIVE -> ACC2
        TimelineModel.FAILED -> Color(0xFFFF6B6B)
        else -> MUTED.copy(alpha = 0.5f)
    }
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        Column(Modifier.width(30.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(18.dp).clip(CircleShape).then(
                    if (state == TimelineModel.DONE) Modifier.background(col)
                    else Modifier.border(2.dp, col.copy(alpha = if (state == TimelineModel.ACTIVE) glow else 1f), CircleShape)
                ),
                Alignment.Center
            ) {
                if (state == TimelineModel.DONE) Icon(Icons.Default.Check, null, tint = Color.Black, modifier = Modifier.size(12.dp))
                if (state == TimelineModel.FAILED) Icon(Icons.Default.Close, null, tint = col, modifier = Modifier.size(12.dp))
                if (state == TimelineModel.ACTIVE) Box(Modifier.size(8.dp).clip(CircleShape).background(col.copy(alpha = glow)))
            }
            if (!last) {
                Box(
                    Modifier.width(2.dp).weight(1f)
                        .background(if (state == TimelineModel.DONE) GOLD.copy(alpha = 0.7f) else Color(0x33F5B301))
                )
            }
        }
        Column(Modifier.padding(start = 10.dp, bottom = 14.dp)) {
            Text(
                step.text, color = if (state == TimelineModel.PENDING) MUTED else CREAM, fontSize = 14.sp,
                fontWeight = if (state == TimelineModel.ACTIVE) FontWeight.Bold else FontWeight.Normal
            )
            if (state == TimelineModel.DONE && step.result.isNotBlank()) {
                Text(step.result.take(90), color = MUTED, fontSize = 11.sp, maxLines = 2)
            }
        }
    }
}
