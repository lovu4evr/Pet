package com.swarmdeck.guard

import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** Tamper-evident log: every entry commits to the hash of the previous one, so editing or deleting a middle line is detectable. */
object HashChain {
    const val GENESIS = "0000000000000000000000000000000000000000000000000000000000000000"

    data class Entry(val ts: Long, val kind: String, val detail: String, val prev: String, val hash: String)

    fun sha256(s: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder()
        for (b in d) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    fun clean(s: String): String = SecretScan.redact(s).replace(Regex("[\\r\\n|]+"), " ").take(240)

    fun make(prev: String, ts: Long, kind: String, detail: String): Entry {
        val k = clean(kind).take(24)
        val d = clean(detail)
        return Entry(ts, k, d, prev, sha256("$prev|$ts|$k|$d"))
    }

    /** Returns -1 when the whole list is intact, otherwise the index of the first bad entry. */
    fun verify(l: List<Entry>): Int {
        for (i in l.indices) {
            val e = l[i]
            if (i > 0 && e.prev != l[i - 1].hash) return i
            if (sha256("${e.prev}|${e.ts}|${e.kind}|${e.detail}") != e.hash) return i
        }
        return -1
    }

    fun toLine(e: Entry): String =
        JSONObject().put("t", e.ts).put("k", e.kind).put("d", e.detail).put("p", e.prev).put("h", e.hash).toString()

    fun fromLine(line: String): Entry =
        try {
            val o = JSONObject(line)
            Entry(o.getLong("t"), o.getString("k"), o.getString("d"), o.getString("p"), o.getString("h"))
        } catch (_: Exception) {
            Entry(0L, "corrupt", "", "", "BAD")
        }
}

/** File-backed hash-chained log (plain JSON lines; secrets are redacted before they are written). */
class GuardLog(private val file: File, private val maxLines: Int = 2000) {
    @Synchronized
    fun read(): List<HashChain.Entry> {
        if (!file.isFile) return emptyList()
        return file.readLines().filter { it.isNotBlank() }.map { HashChain.fromLine(it) }
    }

    @Synchronized
    fun append(kind: String, detail: String, ts: Long = System.currentTimeMillis()): HashChain.Entry {
        val all = read()
        val prev = all.lastOrNull()?.hash ?: HashChain.GENESIS
        val e = HashChain.make(prev, ts, kind, detail)
        file.parentFile?.mkdirs()
        if (all.size < maxLines) {
            file.appendText(HashChain.toLine(e) + "\n")
        } else {
            val kept = (all + e).takeLast(maxLines)
            file.writeText(kept.joinToString("\n") { HashChain.toLine(it) } + "\n")
        }
        return e
    }

    fun verify(): Int = HashChain.verify(read())
}
