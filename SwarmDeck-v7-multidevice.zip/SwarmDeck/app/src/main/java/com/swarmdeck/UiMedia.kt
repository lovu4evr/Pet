package com.swarmdeck

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File

private fun loadBmp(f: File): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    var s = 1
    while (o.outWidth / s > 1600) s *= 2
    return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
}

@Composable
fun AudioPlayer(f: File) {
    var mp by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    DisposableEffect(f.path) { onDispose { try { mp?.release() } catch (_: Exception) {} } }
    Button({
        if (playing) {
            try { mp?.stop(); mp?.release() } catch (_: Exception) {}
            mp = null; playing = false
        } else {
            try {
                val m = MediaPlayer()
                m.setDataSource(f.path)
                m.prepare()
                m.setOnCompletionListener { playing = false }
                m.start()
                mp = m; playing = true
            } catch (_: Exception) { playing = false }
        }
    }) { Text(if (playing) "⏹ Stop audio" else "▶ Play audio") }
}

/** Renders generated media (images / video / audio) stored in the app's private media folder. */
@Composable
fun MediaBlock(c: Context, rel: String) {
    val file = remember(rel) { Parse.resolveIn(c.filesDir, rel) }
    var note by remember(rel) { mutableStateOf("") }
    if (file == null || !file.isFile) {
        Text("(media file not found)", color = MUTED, fontSize = 12.sp)
    } else {
        val ext = file.extension.lowercase()
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x66000000)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (ext == "mp4" || ext == "webm") {
                var play by remember(rel) { mutableStateOf(false) }
                if (play) AndroidView(
                    factory = { ctx ->
                        VideoView(ctx).apply {
                            setVideoPath(file.path)
                            val mc = MediaController(ctx)
                            mc.setAnchorView(this)
                            setMediaController(mc)
                            setOnPreparedListener { start() }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(260.dp)
                ) else Button({ play = true }) { Text("▶ Play video") }
            } else if (ext == "wav" || ext == "mp3" || ext == "ogg" || ext == "m4a") {
                AudioPlayer(file)
            } else {
                val bmp = remember(rel) { loadBmp(file) }
                if (bmp != null) Image(bmp.asImageBitmap(), "Generated image", Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.FillWidth)
                else Text("(cannot show this image)", color = MUTED, fontSize = 12.sp)
            }
            Row {
                TextButton({ note = Gallery.save(c, file) }) { Text("💾 Save to gallery", fontSize = 12.sp, color = ACC2) }
                if (note.isNotEmpty()) Text(note, color = MUTED, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp))
            }
        }
    }
}
