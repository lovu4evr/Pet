package com.swarmdeck.guard

import android.content.Context
import com.swarmdeck.Audit
import com.swarmdeck.Bus
import com.swarmdeck.CancelledException
import com.swarmdeck.Confirm
import com.swarmdeck.Memory
import com.swarmdeck.Parse
import com.swarmdeck.Run
import com.swarmdeck.Store
import org.json.JSONObject
import java.io.File

/**
 * Zero-Trust gate in front of every tool call (called from Tools.exec).
 * BLOCK = never runs. CONFIRM = fresh approval every time (never "trust this run"). Every decision goes into a
 * hash-chained log, and file writes / memory saves are journaled so they can be undone.
 * If the gate itself fails, the action is NOT run (fail closed).
 */
object Guard {
    private val SESSION: String = java.lang.Long.toString(System.currentTimeMillis(), 36)
    private val approvalLock = Any()
    private val approvedScreens: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

    @Volatile private var undoStoreRef: UndoStore? = null
    @Volatile private var chainRef: GuardLog? = null

    fun workspace(c: Context): File = File(c.filesDir, "workspace").apply { mkdirs() }

    @Synchronized
    fun undoStore(c: Context): UndoStore {
        val cur = undoStoreRef
        if (cur != null) return cur
        val s = UndoStore(File(c.filesDir, "undo"))
        undoStoreRef = s
        return s
    }

    @Synchronized
    fun chain(c: Context): GuardLog {
        val cur = chainRef
        if (cur != null) return cur
        val l = GuardLog(File(c.filesDir, "guard.chain"))
        chainRef = l
        return l
    }

    fun isStrict(c: Context): Boolean = Store.p(c).getString("guard_level", "normal") == "strict"

    fun setStrict(c: Context, strict: Boolean) {
        Store.p(c).edit().putString("guard_level", if (strict) "strict" else "normal").apply()
    }

    fun memoryDeleter(c: Context): (String, String) -> Int = { key, value ->
        val k = key.trim().take(120)
        val v = value.trim().take(2000)
        val hits = Memory.all(c).filter { it.key == k && it.value == v }
        hits.forEach { Memory.delete(c, it.id) }
        hits.size
    }

    /** Returns null when the tool may run, otherwise the text to give back to the agent instead of running it. */
    fun gate(c: Context, run: Run, tool: String, a: JSONObject): String? {
        try {
            val root = workspace(c)
            val target: File? = if (tool == "file_write") Parse.resolveIn(root, a.optString("path")) else null
            val exists = target != null && target.isFile
            val ctx = GuardCtx(isStrict(c), exists, if (exists && target != null) target.length() else 0L)
            var s = RiskClassifier.assess(tool, a, ctx)
            // A screenshot needs approval once per task and device; after that the agent can look again to verify its work.
            val screenKey: String? = if (tool == "device_screen") run.id.toString() + ":" + a.optString("device").trim().lowercase() else null
            if (screenKey != null && s.risk == Risk.CONFIRM && screenKey in approvedScreens) {
                s = Assessment(Risk.NOTICE, listOf("screen already approved for this task"))
            }
            val log = chain(c)

            when (s.risk) {
                Risk.BLOCK -> {
                    val why = s.reasons.joinToString("; ")
                    log.append("block", "$tool: $why")
                    Audit.log(c, "guard_block", "$tool: $why")
                    Bus.think("Zero-Trust blocked $tool: $why")
                    return RiskClassifier.blockMessage(s)
                }
                Risk.CONFIRM -> {
                    val r = synchronized(approvalLock) {
                        Confirm.ask(c, run, s.title, RiskClassifier.approvalDetail(s), true)
                    }
                    if (r == 0) {
                        log.append("deny", "$tool: ${s.title}")
                        return "DENIED by the user. Do not retry; stop and report."
                    }
                    log.append("approve", "$tool: ${s.title}")
                    if (screenKey != null) {
                        if (approvedScreens.size > 50) approvedScreens.clear()
                        approvedScreens.add(screenKey)
                    }
                }
                Risk.NOTICE -> log.append("allow", "$tool: ${s.reasons.joinToString("; ")}")
                Risk.SAFE -> {
                }
            }

            val group = "$SESSION-${run.id}"
            if (tool == "file_write" && target != null) {
                val rel = target.canonicalFile.relativeTo(root.canonicalFile).path
                undoStore(c).snapshotFile(group, rel, target, "wrote $rel")
                    ?: return "Refused: the existing file is too large to back up, so this overwrite could not be undone."
            }
            if (tool == "memory_save") {
                val k = a.optString("key").trim().take(120)
                val v = a.optString("value").trim().take(2000)
                if (k.isNotEmpty() && v.isNotEmpty() && Memory.all(c).none { it.key == k && it.value == v }) {
                    undoStore(c).recordMemory(group, k, v, "saved memory \"$k\"")
                }
            }
            return null
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            try {
                Audit.log(c, "guard_error", "$tool: ${e.message}")
            } catch (_: Exception) {
            }
            return "Zero-Trust check failed (${e.message}); the action was not run."
        }
    }
}
