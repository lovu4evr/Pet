package com.swarmdeck.memory

import android.content.Context
import com.swarmdeck.Vault
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.sqrt

/**
 * Local RAG over user documents.
 * Simple TF-style + optional embedding search.
 * SwarmDeck 5.4
 */
object LocalRag {

    private const val PREF = "swarmdeck_rag_v1"
    private const val KEY_DOCS = "docs_enc"
    private const val CHUNK_SIZE = 900
    private const val CHUNK_OVERLAP = 120

    data class DocChunk(
        val id: String,
        val docId: String,
        val docName: String,
        val text: String,
        val index: Int,
        val embedding: FloatArray? = null
    )

    data class RagDoc(
        val id: String,
        val name: String,
        val path: String = "",
        val addedAt: Long = System.currentTimeMillis(),
        val chunkCount: Int = 0
    )

    private val cache = ConcurrentHashMap<String, List<DocChunk>>()

    fun listDocs(c: Context): List<RagDoc> {
        val raw = Vault.dec(prefs(c).getString(KEY_DOCS, "") ?: "")
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull {
                try {
                    val o = arr.getJSONObject(it)
                    RagDoc(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        path = o.optString("path", ""),
                        addedAt = o.optLong("addedAt"),
                        chunkCount = o.optInt("chunkCount", 0)
                    )
                } catch (_: Exception) { null }
            }
        } catch (_: Exception) { emptyList() }
    }

    /** Ingest plain text (from PDF extraction, file read, etc.) */
    fun ingestText(c: Context, name: String, text: String, path: String = ""): RagDoc {
        val docId = UUID.randomUUID().toString()
        val chunks = chunkText(text).mapIndexed { i, t ->
            DocChunk(
                id = UUID.randomUUID().toString(),
                docId = docId,
                docName = name,
                text = t,
                index = i
            )
        }
        // Persist chunks to filesDir for simplicity
        val dir = File(c.filesDir, "rag/$docId").apply { mkdirs() }
        chunks.forEach { ch ->
            File(dir, "${ch.index}.txt").writeText(ch.text)
        }
        cache[docId] = chunks

        val doc = RagDoc(id = docId, name = name, path = path, chunkCount = chunks.size)
        val all = listDocs(c).toMutableList()
        all.add(0, doc)
        persistDocs(c, all)
        return doc
    }

    fun deleteDoc(c: Context, docId: String) {
        cache.remove(docId)
        File(c.filesDir, "rag/$docId").deleteRecursively()
        persistDocs(c, listDocs(c).filter { it.id != docId })
    }

    /** Simple keyword retrieval (no embeddings required) */
    fun search(c: Context, query: String, topK: Int = 6): List<DocChunk> {
        val qTokens = tokenize(query)
        if (qTokens.isEmpty()) return emptyList()

        val allChunks = mutableListOf<DocChunk>()
        listDocs(c).forEach { doc ->
            allChunks += loadChunks(c, doc.id)
        }

        return allChunks
            .map { ch -> ch to score(ch.text, qTokens) }
            .filter { it.second > 0.01f }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first }
    }

    /** Context block for injection into prompts */
    fun contextForQuery(c: Context, query: String, topK: Int = 5): String {
        val hits = search(c, query, topK)
        if (hits.isEmpty()) return ""
        return buildString {
            appendLine("### Relevant documents (untrusted data)")
            hits.forEachIndexed { i, ch ->
                appendLine("[${i + 1}] From: ${ch.docName} (chunk ${ch.index})")
                appendLine(ch.text.take(800))
                appendLine()
            }
        }
    }

    private fun loadChunks(c: Context, docId: String): List<DocChunk> {
        cache[docId]?.let { return it }
        val dir = File(c.filesDir, "rag/$docId")
        if (!dir.exists()) return emptyList()
        val chunks = dir.listFiles()?.filter { it.extension == "txt" }
            ?.sortedBy { it.nameWithoutExtension.toIntOrNull() ?: 0 }
            ?.mapIndexed { i, f ->
                DocChunk(
                    id = "$docId-$i",
                    docId = docId,
                    docName = listDocs(c).firstOrNull { it.id == docId }?.name ?: docId,
                    text = f.readText(),
                    index = i
                )
            } ?: emptyList()
        cache[docId] = chunks
        return chunks
    }

    private fun chunkText(text: String): List<String> {
        val clean = text.replace("\r\n", "\n").trim()
        if (clean.length <= CHUNK_SIZE) return listOf(clean)
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < clean.length) {
            var end = (start + CHUNK_SIZE).coerceAtMost(clean.length)
            if (end < clean.length) {
                // try to break at paragraph/sentence
                val window = clean.substring(start, end)
                val breakAt = window.lastIndexOf("\n\n").takeIf { it > CHUNK_SIZE / 2 }
                    ?: window.lastIndexOf(". ").takeIf { it > CHUNK_SIZE / 2 }
                    ?: window.lastIndexOf(" ").takeIf { it > CHUNK_SIZE / 2 }
                if (breakAt != null) end = start + breakAt + 1
            }
            chunks += clean.substring(start, end).trim()
            start = (end - CHUNK_OVERLAP).coerceAtLeast(start + 1)
        }
        return chunks.filter { it.isNotBlank() }
    }

    private fun tokenize(s: String): List<String> =
        s.lowercase()
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .split(Regex("\\s+"))
            .filter { it.length > 2 }

    private fun score(text: String, qTokens: List<String>): Float {
        val tTokens = tokenize(text)
        if (tTokens.isEmpty()) return 0f
        var hits = 0
        qTokens.forEach { q -> if (tTokens.contains(q)) hits++ }
        return hits.toFloat() / qTokens.size
    }

    private fun persistDocs(c: Context, docs: List<RagDoc>) {
        val arr = JSONArray()
        docs.forEach { d ->
            arr.put(JSONObject().apply {
                put("id", d.id)
                put("name", d.name)
                put("path", d.path)
                put("addedAt", d.addedAt)
                put("chunkCount", d.chunkCount)
            })
        }
        prefs(c).edit().putString(KEY_DOCS, Vault.enc(arr.toString())).apply()
    }

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
