package com.swarmdeck.memgraph

import android.content.Context
import com.swarmdeck.Memory
import com.swarmdeck.Store
import com.swarmdeck.Vault
import com.swarmdeck.memory.GoalStore
import java.util.UUID

/** Bridges the existing stores (memories, goals) and the new decision log into one memory graph. */
object GraphHub {
    private const val K_DEC = "decisions_enc"
    private const val MAX_DECISIONS = 200

    fun decisions(c: Context): List<Decision> =
        DecisionJson.fromJson(Vault.dec(Store.p(c).getString(K_DEC, "") ?: ""))

    private fun saveDecisions(c: Context, l: List<Decision>) {
        Store.p(c).edit().putString(K_DEC, Vault.enc(DecisionJson.toJson(l))).apply()
    }

    fun goalsIn(c: Context): List<GoalIn> = GoalStore.list(c).map {
        GoalIn(it.id, it.title, it.description, it.status.name, it.priority, it.progress, it.updatedAt, it.dueAt)
    }

    fun factsIn(c: Context): List<FactIn> = Memory.all(c).map { FactIn(it.id, it.key, it.value, it.ts, it.pinned) }

    @Synchronized
    fun addDecision(c: Context, title: String, reason: String): Pair<Decision, GoalIn?> {
        val goals = goalsIn(c)
        val gid = GraphBuilder.guessGoal("$title $reason", goals)
        val d = Decision(UUID.randomUUID().toString().take(8), System.currentTimeMillis(), title, reason, gid, "OPEN")
        saveDecisions(c, (listOf(d) + decisions(c)).take(MAX_DECISIONS))
        return d to goals.firstOrNull { it.id == gid }
    }

    @Synchronized
    fun setStatus(c: Context, id: String, status: String): Decision? {
        val all = decisions(c)
        val d = all.firstOrNull { it.id == id.trim() } ?: return null
        val nd = d.copy(status = status)
        saveDecisions(c, all.map { if (it.id == d.id) nd else it })
        return nd
    }

    fun build(c: Context): MemGraph = GraphBuilder.build(factsIn(c), goalsIn(c), decisions(c))

    fun suggestions(c: Context): List<Suggestion> =
        Proactive.suggestions(goalsIn(c), decisions(c), System.currentTimeMillis())
}
