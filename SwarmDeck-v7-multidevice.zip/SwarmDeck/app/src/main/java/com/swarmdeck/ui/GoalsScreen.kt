package com.swarmdeck.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.core.Goal
import com.swarmdeck.core.GoalStatus
import com.swarmdeck.memory.GoalStore

private val Gold = Color(0xFFD4AF37)
private val DarkBg = Color(0xFF0D0D0D)
private val CardBg = Color(0xFF1A1A1A)

@Composable
fun GoalsScreen(
    context: android.content.Context,
    onBack: () -> Unit
) {
    var goals by remember { mutableStateOf(GoalStore.list(context)) }
    var showAdd by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf(3) }

    fun refresh() { goals = GoalStore.list(context) }

    Column(Modifier.fillMaxSize().background(DarkBg)) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = Gold)
            }
            Text("Long-term Goals", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, null, tint = Gold)
            }
        }

        if (goals.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No goals yet.\nTap + to create one.", color = Color.Gray, fontSize = 16.sp)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(goals, key = { it.id }) { g ->
                    GoalCard(g,
                        onToggle = {
                            val next = if (g.status == GoalStatus.ACTIVE) GoalStatus.COMPLETED else GoalStatus.ACTIVE
                            GoalStore.updateProgress(context, g.id, if (next == GoalStatus.COMPLETED) 1f else g.progress, next)
                            refresh()
                        },
                        onDelete = {
                            GoalStore.delete(context, g.id)
                            refresh()
                        }
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("New Goal", color = Gold) },
            text = {
                Column {
                    OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(desc, { desc = it }, label = { Text("Description (optional)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text("Priority: $priority", color = Color.White)
                    Slider(value = priority.toFloat(), onValueChange = { priority = it.toInt() }, valueRange = 1f..5f, steps = 3, colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isNotBlank()) {
                        GoalStore.create(context, title, desc, priority)
                        title = ""; desc = ""; priority = 3
                        showAdd = false
                        refresh()
                    }
                }) { Text("Create", color = Gold) }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } },
            containerColor = CardBg
        )
    }
}

@Composable
private fun GoalCard(g: Goal, onToggle: () -> Unit, onDelete: () -> Unit) {
    val statusColor = when (g.status) {
        GoalStatus.ACTIVE -> Gold
        GoalStatus.COMPLETED -> Color(0xFF4CAF50)
        GoalStatus.PAUSED -> Color.Gray
        GoalStatus.CANCELLED -> Color.Red
    }
    Card(
        Modifier.fillMaxWidth().border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(g.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Text("P${g.priority}", color = Gold, fontSize = 12.sp)
            }
            if (g.description.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(g.description, color = Color.Gray, fontSize = 13.sp, maxLines = 2)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { g.progress },
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = statusColor,
                trackColor = Color.DarkGray
            )
            Spacer(Modifier.height(8.dp))
            Row {
                Text(g.status.name, color = statusColor, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = onToggle) {
                    Text(if (g.status == GoalStatus.ACTIVE) "Complete" else "Reopen", color = Gold, fontSize = 12.sp)
                }
                TextButton(onClick = onDelete) {
                    Text("Delete", color = Color.Red.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
        }
    }
}
