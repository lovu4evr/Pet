package com.swarmdeck.guard

import android.content.Context
import com.swarmdeck.Audit
import com.swarmdeck.Bus
import com.swarmdeck.Run
import com.swarmdeck.Turn

/**
 * Chat commands for the Zero-Trust layer:
 *   undo | undo: list | undo: last | undo: run | undo: <number>
 *   guard | guard: status | guard: strict | guard: normal | guard: log [n] | guard: verify
 * There is intentionally no "off": blocking of secrets / dangerous actions cannot be disabled.
 */
object GuardCmd {
    private val CMD = Regex("^(undo|guard)\\s*(?::\\s*(.*))?$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    fun handle(c: Context, run: Run, q: String): Turn? {
        val m = CMD.find(q.trim()) ?: return null
        val arg = m.groupValues[2].trim()
        val text = if (m.groupValues[1].equals("undo", true)) undo(c, arg) else guard(c, arg)
        return Turn(false, text, "", emptyList(), Bus.thinkSnapshot())
    }

    private fun fmt(ts: Long): String = java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.US).format(java.util.Date(ts))

    private fun undo(c: Context, arg: String): String {
        val store = Guard.undoStore(c)
        val root = Guard.workspace(c)
        val del = Guard.memoryDeleter(c)
        val log = Guard.chain(c)
        if (arg.isEmpty() || arg.equals("list", true)) {
            val l = store.list().take(10)
            if (l.isEmpty()) return "Nothing to undo yet. File writes and memory saves made by agents are recorded here."
            return "### Undo journal\n" + l.joinToString("\n") { "- #${it.id} · ${fmt(it.ts)} · ${it.desc}" } +
                "\n\nUse `undo: last`, `undo: run` (everything the last agent run changed) or `undo: <number>`."
        }
        if (arg.equals("last", true)) {
            val e = store.list().firstOrNull() ?: return "Nothing to undo."
            val msg = store.undo(e.id, root, del)
            log.append("undo", "#${e.id} ${e.desc}")
            Audit.log(c, "undo", "#${e.id} ${e.desc}")
            return msg
        }
        if (arg.equals("run", true)) {
            val g = store.newestGroup() ?: return "Nothing to undo."
            val msg = store.undoGroup(g, root, del)
            log.append("undo", "run $g")
            Audit.log(c, "undo", "run $g")
            return msg
        }
        val id = arg.toIntOrNull()
        if (id != null) {
            val msg = store.undo(id, root, del)
            log.append("undo", "#$id")
            Audit.log(c, "undo", "#$id")
            return msg
        }
        return "Usage: `undo: list`, `undo: last`, `undo: run`, `undo: <number>`"
    }

    private fun guard(c: Context, arg: String): String {
        val log = Guard.chain(c)
        if (arg.isEmpty() || arg.equals("status", true)) {
            val entries = log.read()
            val bad = HashChain.verify(entries)
            val recent = entries.takeLast(500).groupingBy { it.kind }.eachCount()
            val mode = if (Guard.isStrict(c)) "strict" else "normal"
            val integrity = if (bad < 0) "intact (${entries.size} entries)" else "TAMPERED at entry #$bad"
            return "### Zero-Trust\n" +
                "- Mode: **$mode**\n" +
                "- Last ${minOf(entries.size, 500)} events: blocked ${recent["block"] ?: 0}, approved ${recent["approve"] ?: 0}, " +
                "denied ${recent["deny"] ?: 0}, allowed ${recent["allow"] ?: 0}\n" +
                "- Log integrity: $integrity\n" +
                "- Undo journal: ${Guard.undoStore(c).list().size} entries\n\n" +
                "Commands: `guard: strict`, `guard: normal`, `guard: log`, `guard: verify`, `undo: list`"
        }
        if (arg.equals("strict", true)) {
            Guard.setStrict(c, true)
            log.append("level", "strict")
            return "Strict mode ON. Every network access, file write, memory save, code run and media generation now needs your approval each time. Secrets and dangerous actions stay blocked in every mode."
        }
        if (arg.equals("normal", true)) {
            Guard.setStrict(c, false)
            log.append("level", "normal")
            return "Normal mode. Dangerous actions are blocked, risky ones ask first, safe ones run. Secrets stay blocked."
        }
        if (arg.equals("verify", true)) {
            val entries = log.read()
            val bad = HashChain.verify(entries)
            return if (bad < 0) "Log is intact: ${entries.size} entries, chain verified." else "Log was modified: the chain breaks at entry #$bad."
        }
        if (arg.equals("log", true) || arg.startsWith("log ", true)) {
            val n = (arg.substring(3).trim().toIntOrNull() ?: 12).coerceIn(1, 50)
            val l = log.read().takeLast(n)
            if (l.isEmpty()) return "The Zero-Trust log is empty."
            return "### Zero-Trust log\n" + l.joinToString("\n") { "- ${fmt(it.ts)} · **${it.kind}** · ${it.detail}" }
        }
        return "Usage: `guard: status`, `guard: strict`, `guard: normal`, `guard: log [n]`, `guard: verify`"
    }
}
