package com.swarmdeck.device

import org.json.JSONArray
import org.json.JSONObject

data class PairedDevice(val name: String, val host: String, val port: Int, val keyHex: String, val os: String, val addedAt: Long)

object DevicesJson {
    fun toJson(l: List<PairedDevice>): String {
        val arr = JSONArray()
        l.forEach {
            arr.put(JSONObject().put("name", it.name).put("host", it.host).put("port", it.port).put("key", it.keyHex).put("os", it.os).put("at", it.addedAt))
        }
        return arr.toString()
    }

    fun fromJson(raw: String): List<PairedDevice> {
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                PairedDevice(o.getString("name"), o.getString("host"), o.getInt("port"), o.getString("key"), o.optString("os", "?"), o.optLong("at"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}

/** Validation shared by the Zero-Trust classifier and the client. Mirrors the companion's own checks (defense in depth). Pure JVM. */
object DeviceRules {
    val ACTIONS = setOf(
        "ping", "screen_info", "screenshot", "mouse_move", "click", "scroll", "type", "key",
        "open_url", "open_app", "clipboard_get", "clipboard_set"
    )

    /** Actions that only check the connection or read the screen size. */
    val QUIET = setOf("ping", "screen_info")

    const val MAX_TYPE = 500
    const val MAX_URL = 500
    const val MAX_CLIP = 4000
    const val DEFAULT_PORT = 8765

    private val SYN = mapOf(
        "control" to "ctrl", "ctl" to "ctrl", "option" to "alt", "opt" to "alt", "windows" to "win", "super" to "win",
        "meta" to "win", "cmd" to "win", "command" to "win", "del" to "delete", "escape" to "esc", "return" to "enter",
        "pgup" to "pageup", "pgdn" to "pagedown"
    )
    private val NAMED = setOf(
        "enter", "tab", "space", "esc", "backspace", "delete", "up", "down", "left", "right", "home", "end",
        "pageup", "pagedown", "ctrl", "alt", "shift", "win"
    )
    private val BLOCKED: List<Pair<Set<String>, String>> = listOf(
        setOf("win", "r") to "the Run dialog",
        setOf("win", "x") to "the power-user menu",
        setOf("win", "l") to "screen lock",
        setOf("win", "space") to "the launcher",
        setOf("ctrl", "alt", "delete") to "the security screen",
        setOf("ctrl", "shift", "esc") to "the task manager",
        setOf("alt", "f2") to "the Run dialog",
        setOf("ctrl", "alt", "t") to "a terminal",
        setOf("alt", "f4") to "closing windows",
        setOf("win", "q") to "quit/search"
    )
    private val APP_BAD = listOf(
        "powershell", "pwsh", "cmd", "terminal", "console", "bash", "zsh", "shell", "python", "regedit", "registry",
        "taskmgr", "task manager", "settings", "control panel", "system preferences", "activity monitor", "keychain",
        "installer", "setup", "msiexec", "wscript", "cscript", "iterm", "putty", "ssh"
    )

    fun parseCombo(combo: String): Pair<List<String>?, String?> {
        val parts = combo.replace(" ", "").split("+").map { it.trim().lowercase() }
        if (parts.isEmpty() || parts.size > 4 || parts.any { it.isEmpty() }) return null to "combo must have 1-4 keys, e.g. ctrl+c"
        val out = ArrayList<String>()
        for (raw in parts) {
            val p = SYN[raw] ?: raw
            val single = p.length == 1 && p[0].code < 128 && p[0].isLetterOrDigit()
            val digits = if (p.length in 2..3 && p[0] == 'f') p.substring(1) else ""
            val fkey = digits.isNotEmpty() && digits.all { it in '0'..'9' } && (digits.toIntOrNull() ?: 0) in 1..12
            if (!(single || p in NAMED || fkey)) return null to "unsupported key: $p"
            out.add(p)
        }
        return out to null
    }

    fun comboBlocked(tokens: List<String>): String? {
        val s = tokens.toSet()
        if (s == setOf("win")) return "the Start menu / launcher"
        for ((combo, why) in BLOCKED) if (s.containsAll(combo)) return why
        return null
    }

    fun blockedApp(name: String): String? {
        val low = name.lowercase()
        return if (APP_BAD.any { low.contains(it) }) "\"$name\" looks like a shell, installer or system-settings app" else null
    }

    /** Only addresses on your own network (or *.local / localhost) may be contacted, so the phone can never be used to reach the internet. */
    fun isPrivateHost(host: String): Boolean {
        val h = host.trim().lowercase()
        if (h == "localhost") return true
        if (h.endsWith(".local")) return Regex("[a-z0-9-]+(\\.[a-z0-9-]+)*\\.local").matches(h)
        val parts = h.split(".")
        if (parts.size != 4 || parts.any { it.isEmpty() || it.length > 3 || !it.all { c -> c in '0'..'9' } }) return false
        val n = parts.map { it.toInt() }
        if (n.any { it > 255 }) return false
        val a = n[0]
        val b = n[1]
        return a == 10 || a == 127 || (a == 172 && b in 16..31) || (a == 192 && b == 168) || (a == 169 && b == 254) || (a == 100 && b in 64..127)
    }

    /** "192.168.1.5:8765" -> ("192.168.1.5", 8765). Syntax only; callers must also check isPrivateHost. */
    fun parseEndpoint(text: String): Pair<String, Int>? {
        var t = text.trim().removePrefix("http://")
        if (t.endsWith("/")) t = t.dropLast(1)
        if (t.isEmpty() || t.contains("/") || t.contains("@") || t.contains(" ")) return null
        val i = t.lastIndexOf(':')
        val host: String
        val port: Int
        if (i < 0) {
            host = t
            port = DEFAULT_PORT
        } else {
            host = t.substring(0, i)
            port = t.substring(i + 1).toIntOrNull() ?: return null
        }
        if (port !in 1..65535) return null
        if (host.isEmpty() || !Regex("[A-Za-z0-9.-]+").matches(host)) return null
        return host to port
    }

    private fun num(a: JSONObject, key: String): Double? {
        val v = a.opt(key) ?: return null
        return when (v) {
            is Number -> v.toDouble()
            is String -> v.trim().toDoubleOrNull()
            else -> null
        }
    }

    private fun intIn(a: JSONObject, key: String, lo: Int, hi: Int): Int? {
        val d = num(a, key) ?: return null
        if (d.isNaN() || d < lo || d > hi) return null
        return Math.round(d).toInt()
    }

    /** Turns the flat tool arguments into the companion's args object, or returns an error text. */
    fun buildArgs(action: String, a: JSONObject): Pair<JSONObject?, String?> {
        val o = JSONObject()
        when (action) {
            "ping", "screen_info", "screenshot", "clipboard_get" -> {
            }
            "click", "mouse_move" -> {
                val x = intIn(a, "x", 0, 10000) ?: return null to "x must be a number between 0 and 10000"
                val y = intIn(a, "y", 0, 10000) ?: return null to "y must be a number between 0 and 10000"
                o.put("x", x).put("y", y)
                if (action == "click") {
                    val b = a.optString("button", "left").lowercase().ifEmpty { "left" }
                    if (b != "left" && b != "right") return null to "button must be left or right"
                    o.put("button", b)
                    if (a.optBoolean("double", false)) o.put("double", true)
                }
            }
            "scroll" -> {
                val n = intIn(a, "amount", -30, 30) ?: return null to "amount must be a number between -30 and 30"
                o.put("amount", n)
            }
            "type" -> {
                val t = a.optString("text")
                if (t.isEmpty()) return null to "text is required"
                if (t.length > MAX_TYPE) return null to "text too long (max $MAX_TYPE)"
                if (!t.all { it == '\n' || it.code in 32..126 }) return null to "only printable ASCII can be typed"
                o.put("text", t)
            }
            "key" -> {
                val (tokens, err) = parseCombo(a.optString("combo"))
                if (tokens == null) return null to err
                val why = comboBlocked(tokens)
                if (why != null) return null to "blocked key combination ($why)"
                o.put("combo", tokens.joinToString("+"))
            }
            "open_url" -> {
                val u = a.optString("url").trim()
                if (!(u.startsWith("http://") || u.startsWith("https://")) || u.length > MAX_URL) {
                    return null to "only http(s) URLs up to $MAX_URL characters are allowed"
                }
                o.put("url", u)
            }
            "open_app" -> {
                val n = a.optString("app").trim()
                if (n.isEmpty() || n.length > 40 || !Regex("[A-Za-z0-9 ._-]+").matches(n)) return null to "app must be a short plain name"
                val bad = blockedApp(n)
                if (bad != null) return null to bad
                o.put("name", n)
            }
            "clipboard_set" -> {
                val t = a.optString("text")
                if (t.isEmpty() || t.length > MAX_CLIP) return null to "text is required (max $MAX_CLIP)"
                o.put("text", t)
            }
            else -> return null to "unknown action \"$action\""
        }
        return o to null
    }
}
