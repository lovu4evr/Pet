package com.swarmdeck.memgraph

import org.json.JSONArray
import org.json.JSONObject

enum class NodeType { FACT, GOAL, DECISION, TOPIC }
enum class EdgeKind { ABOUT, RELATED, SERVES }

data class GNode(
    val id: String,
    val type: NodeType,
    val label: String,
    val detail: String = "",
    val weight: Float = 1f,
    val ts: Long = 0L
)

data class GEdge(val a: String, val b: String, val kind: EdgeKind, val weight: Float = 1f)

data class MemGraph(val nodes: List<GNode>, val edges: List<GEdge>) {
    private val byId: Map<String, GNode> by lazy { nodes.associateBy { it.id } }

    fun node(id: String): GNode? = byId[id]

    fun neighbors(id: String): List<GNode> =
        edges.mapNotNull { e ->
            when (id) {
                e.a -> byId[e.b]
                e.b -> byId[e.a]
                else -> null
            }
        }.distinctBy { it.id }
}

data class FactIn(val id: String, val key: String, val value: String, val ts: Long, val pinned: Boolean)

data class GoalIn(
    val id: String,
    val title: String,
    val description: String,
    val status: String,
    val priority: Int,
    val progress: Float,
    val updatedAt: Long,
    val dueAt: Long?
)

data class Decision(
    val id: String,
    val ts: Long,
    val title: String,
    val reason: String,
    val goalId: String?,
    val status: String
)

/** Cheap multilingual keyword extraction (English + common Hinglish fillers removed). Pure JVM. */
object Keywords {
    private val STOP = setOf(
        "the", "and", "for", "with", "that", "this", "from", "have", "has", "had", "was", "were", "are", "you", "your",
        "not", "but", "can", "will", "would", "about", "into", "what", "when", "where", "which", "who", "how", "why",
        "than", "then", "them", "they", "their", "there", "here", "just", "also", "like", "some", "any", "all", "one",
        "two", "its", "our", "out", "use", "using", "get", "got", "make", "made", "want", "need", "more", "very",
        "been", "being", "should", "could", "does", "did", "done", "hai", "hain", "kya", "ki", "ke", "ko", "se", "mein",
        "par", "aur", "nahi", "nhi", "kar", "karo", "karna", "tum", "tha", "thi", "bhi", "ye", "wo", "yeh", "woh",
        "mera", "meri", "mujhe", "apna", "because", "kyunki", "since"
    )
    private val WORD = Regex("[\\p{L}\\p{N}_]+")

    fun of(text: String): Set<String> =
        WORD.findAll(text.lowercase()).map { it.value }.filter { it.length >= 3 && it !in STOP }.take(40).toSet()
}

object GraphBuilder {
    /** Builds the graph from the most recent / pinned facts, goals and decisions. O(n^2) on <= ~300 items, so cap facts. */
    fun build(
        facts: List<FactIn>,
        goals: List<GoalIn>,
        decisions: List<Decision>,
        maxFacts: Int = 250,
        maxTopics: Int = 40,
        maxLinks: Int = 4
    ): MemGraph {
        val nodes = ArrayList<GNode>()
        val edges = ArrayList<GEdge>()
        val kw = LinkedHashMap<String, Set<String>>()

        val usedFacts = facts.sortedWith(compareBy({ !it.pinned }, { -it.ts })).take(maxFacts)
        for (f in usedFacts) {
            val id = "f:" + f.id
            nodes.add(GNode(id, NodeType.FACT, f.key.take(60), f.value.take(300), if (f.pinned) 2f else 1f, f.ts))
            kw[id] = Keywords.of(f.key + " " + f.value)
        }
        for (g in goals) {
            val id = "g:" + g.id
            val w = (4 - g.priority).coerceIn(1, 3) * (if (g.status == "ACTIVE") 1f else 0.5f)
            val detail = g.description.take(200) + (if (g.progress > 0f) " (" + (g.progress * 100).toInt() + "%)" else "")
            nodes.add(GNode(id, NodeType.GOAL, g.title.take(60), detail.trim(), w + 1f, g.updatedAt))
            kw[id] = Keywords.of(g.title + " " + g.description)
        }
        for (d in decisions) {
            val id = "d:" + d.id
            nodes.add(GNode(id, NodeType.DECISION, d.title.take(60), d.reason.take(300), 1.5f, d.ts))
            kw[id] = Keywords.of(d.title + " " + d.reason)
            if (d.goalId != null && goals.any { it.id == d.goalId }) edges.add(GEdge(id, "g:" + d.goalId, EdgeKind.SERVES, 2f))
        }

        val freq = HashMap<String, Int>()
        for (s in kw.values) for (k in s) freq[k] = (freq[k] ?: 0) + 1
        val topics = freq.entries.filter { it.value >= 2 }
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(maxTopics).map { it.key }.toSet()
        for (t in topics) nodes.add(GNode("t:$t", NodeType.TOPIC, t, "", 1f + (freq[t] ?: 0) * 0.3f))
        for ((id, ks) in kw) for (k in ks) if (k in topics) edges.add(GEdge(id, "t:$k", EdgeKind.ABOUT, 1f))

        val ids = kw.keys.toList()
        data class Cand(val a: String, val b: String, val shared: Int)
        val cands = ArrayList<Cand>()
        for (i in ids.indices) {
            for (j in i + 1 until ids.size) {
                val shared = kw.getValue(ids[i]).intersect(kw.getValue(ids[j])).size
                if (shared >= 2) cands.add(Cand(ids[i], ids[j], shared))
            }
        }
        val degree = HashMap<String, Int>()
        for (c in cands.sortedWith(compareBy({ -it.shared }, { it.a }, { it.b }))) {
            if ((degree[c.a] ?: 0) >= maxLinks || (degree[c.b] ?: 0) >= maxLinks) continue
            edges.add(GEdge(c.a, c.b, EdgeKind.RELATED, c.shared.toFloat()))
            degree[c.a] = (degree[c.a] ?: 0) + 1
            degree[c.b] = (degree[c.b] ?: 0) + 1
        }
        return MemGraph(nodes, edges)
    }

    /** Links a new decision to the active goal it shares the most keywords with (needs >= 2 shared). */
    fun guessGoal(text: String, goals: List<GoalIn>): String? {
        val k = Keywords.of(text)
        val best = goals.filter { it.status == "ACTIVE" }
            .map { it to k.intersect(Keywords.of(it.title + " " + it.description)).size }
            .filter { it.second >= 2 }
            .maxByOrNull { it.second }
        return best?.first?.id
    }
}

data class Hit(val node: GNode, val score: Float, val via: String)

object GraphQuery {
    /** Graph-aware recall: direct keyword matches first, then items linked to them (directly or through a shared topic). */
    fun recall(g: MemGraph, query: String, limit: Int = 8): List<Hit> {
        val qk = Keywords.of(query)
        if (qk.isEmpty()) return emptyList()
        val seeds = HashMap<String, Float>()
        for (n in g.nodes) {
            if (n.type == NodeType.TOPIC) continue
            val nk = Keywords.of(n.label + " " + n.detail)
            val overlap = qk.intersect(nk).size
            if (overlap > 0) seeds[n.id] = overlap * n.weight
        }
        val best = HashMap<String, Hit>()
        fun offer(n: GNode, score: Float, via: String) {
            val cur = best[n.id]
            if (cur == null || score > cur.score) best[n.id] = Hit(n, score, via)
        }
        for ((id, s) in seeds) {
            val n = g.node(id) ?: continue
            offer(n, s, "match")
            for (e in g.edges) {
                val other = when (id) {
                    e.a -> g.node(e.b)
                    e.b -> g.node(e.a)
                    else -> null
                } ?: continue
                if (other.type == NodeType.TOPIC) {
                    for (e2 in g.edges) {
                        val o2 = when (other.id) {
                            e2.a -> g.node(e2.b)
                            e2.b -> g.node(e2.a)
                            else -> null
                        } ?: continue
                        if (o2.id != id && o2.type != NodeType.TOPIC) offer(o2, s * 0.3f, "topic " + other.label)
                    }
                } else {
                    offer(other, s * 0.5f, "linked to " + n.label)
                }
            }
        }
        return best.values.sortedWith(compareBy({ -it.score }, { it.node.id })).take(limit)
    }

    fun contextText(hits: List<Hit>): String =
        if (hits.isEmpty()) "(nothing found in the memory graph)"
        else hits.joinToString("\n") { h ->
            "- [" + h.node.type.name + "] " + h.node.label + (if (h.node.detail.isNotBlank()) ": " + h.node.detail.take(200) else "") +
                " (" + h.via + ")"
        }
}

data class Suggestion(val level: Int, val title: String, val action: String, val refId: String?)

/** Rules that turn goals + decisions into proactive nudges. The user (or a mission) decides what to do; nothing runs by itself. */
object Proactive {
    private const val DAY = 86_400_000L

    fun suggestions(goals: List<GoalIn>, decisions: List<Decision>, now: Long): List<Suggestion> {
        val out = ArrayList<Suggestion>()
        for (g in goals) {
            if (g.status != "ACTIVE") continue
            val due = g.dueAt
            val pct = (g.progress * 100).toInt()
            if (due != null && due < now) {
                out.add(Suggestion(1, "Overdue: " + g.title, "My goal \"" + g.title + "\" is overdue (" + pct + "% done). Propose a realistic 3-step recovery plan.", g.id))
            } else if (due != null && due - now <= 3 * DAY && g.progress < 0.8f) {
                val days = ((due - now) / DAY).toInt()
                out.add(Suggestion(1, "Due in $days day(s): " + g.title + " ($pct%)", "My goal \"" + g.title + "\" is due in $days day(s) and only $pct% done. What is the minimum I must do to finish it?", g.id))
            } else if (g.progress >= 0.9f) {
                out.add(Suggestion(3, "Almost done: " + g.title, "Help me finish my goal \"" + g.title + "\" (" + pct + "% done). List what is left.", g.id))
            } else if (now - g.updatedAt >= 7 * DAY) {
                val days = ((now - g.updatedAt) / DAY).toInt()
                out.add(Suggestion(2, "Stalled for $days days: " + g.title, "My goal \"" + g.title + "\" has not moved in $days days. Ask me what is blocking it and suggest the smallest next step.", g.id))
            }
        }
        for (d in decisions) {
            if (d.status == "OPEN" && now - d.ts >= 14 * DAY) {
                out.add(Suggestion(2, "Review decision: " + d.title, "Review my decision \"" + d.title + "\" (reason: " + d.reason.take(120) + "). Was it right? What changed since?", d.id))
            }
        }
        return out.sortedWith(compareBy({ it.level }, { it.title })).take(6)
    }
}

object DecisionText {
    private val SPLITTERS = listOf(" because ", " kyunki ", " kyuki ", " since ", " | ")

    /** "Move to Pune because rent is lower" -> (title, reason). Without a splitter the whole text is the title. */
    fun split(text: String): Pair<String, String> {
        val t = text.trim()
        var cut = -1
        var len = 0
        val low = t.lowercase()
        for (s in SPLITTERS) {
            val i = low.indexOf(s)
            if (i > 0 && (cut < 0 || i < cut)) {
                cut = i
                len = s.length
            }
        }
        if (cut < 0) return t.take(120) to ""
        return t.substring(0, cut).trim().take(120) to t.substring(cut + len).trim().take(400)
    }
}

object DecisionJson {
    fun toJson(l: List<Decision>): String {
        val arr = JSONArray()
        l.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("ts", it.ts).put("title", it.title).put("reason", it.reason)
                    .put("goal", it.goalId ?: "").put("status", it.status)
            )
        }
        return arr.toString()
    }

    fun fromJson(raw: String): List<Decision> {
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Decision(
                    o.getString("id"), o.optLong("ts"), o.getString("title"), o.optString("reason"),
                    o.optString("goal").ifEmpty { null }, o.optString("status", "OPEN")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
