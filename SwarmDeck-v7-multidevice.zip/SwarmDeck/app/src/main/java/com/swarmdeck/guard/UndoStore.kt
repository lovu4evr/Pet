package com.swarmdeck.guard

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class UndoEntry(
    val id: Int,
    val ts: Long,
    val group: String,
    val kind: String,
    val rel: String,
    val existed: Boolean,
    val payload: String,
    val desc: String
)

/**
 * Rollback journal. Before an agent changes a sandbox file, the old content is copied aside; before it saves a memory,
 * the saved text is recorded. `undo` restores or removes exactly that. Entries are grouped per agent run so a whole
 * run can be undone at once. Restores can never write outside the sandbox root. Pure JVM (java.io.File).
 */
class UndoStore(private val dir: File, private val maxEntries: Int = 60, private val maxBytes: Long = 200_000L) {

    private fun indexFile() = File(dir, "index.json")
    private fun bak(id: Int) = File(dir, "$id.bak")

    private fun load(): List<UndoEntry> {
        val f = indexFile()
        if (!f.isFile) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                UndoEntry(
                    o.getInt("id"), o.optLong("ts"), o.optString("group"), o.optString("kind"), o.optString("rel"),
                    o.optBoolean("existed"), o.optString("payload"), o.optString("desc")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun save(l: List<UndoEntry>) {
        dir.mkdirs()
        val arr = JSONArray()
        l.forEach { e ->
            arr.put(
                JSONObject().put("id", e.id).put("ts", e.ts).put("group", e.group).put("kind", e.kind).put("rel", e.rel)
                    .put("existed", e.existed).put("payload", e.payload).put("desc", e.desc)
            )
        }
        indexFile().writeText(arr.toString())
    }

    private fun prune(l: List<UndoEntry>): List<UndoEntry> {
        if (l.size <= maxEntries) return l
        val sorted = l.sortedBy { it.id }
        val drop = sorted.take(l.size - maxEntries)
        drop.forEach { bak(it.id).delete() }
        return sorted.drop(drop.size)
    }

    @Synchronized
    fun list(): List<UndoEntry> = load().sortedByDescending { it.id }

    @Synchronized
    fun newestGroup(): String? = list().firstOrNull()?.group

    /** Returns null when an existing file is too large to back up (the caller must then refuse the overwrite). */
    @Synchronized
    fun snapshotFile(group: String, rel: String, target: File, desc: String, now: Long = System.currentTimeMillis()): UndoEntry? {
        dir.mkdirs()
        val existed = target.isFile
        if (existed && target.length() > maxBytes) return null
        val l = load().toMutableList()
        val id = (l.maxOfOrNull { it.id } ?: 0) + 1
        if (existed) target.copyTo(bak(id), overwrite = true)
        val e = UndoEntry(id, now, group, "file", rel, existed, "", desc)
        l.add(e)
        save(prune(l))
        return e
    }

    @Synchronized
    fun recordMemory(group: String, key: String, value: String, desc: String, now: Long = System.currentTimeMillis()): UndoEntry {
        dir.mkdirs()
        val l = load().toMutableList()
        val id = (l.maxOfOrNull { it.id } ?: 0) + 1
        val e = UndoEntry(id, now, group, "memory", key, false, value, desc)
        l.add(e)
        save(prune(l))
        return e
    }

    @Synchronized
    fun undo(id: Int, root: File, memoryDelete: (String, String) -> Int): String {
        val l = load().toMutableList()
        val e = l.firstOrNull { it.id == id } ?: return "No undo entry #$id."
        val msg = applyUndo(e, root, memoryDelete)
        l.remove(e)
        bak(e.id).delete()
        save(l)
        return msg
    }

    @Synchronized
    fun undoGroup(group: String, root: File, memoryDelete: (String, String) -> Int): String {
        val l = load().toMutableList()
        val mine = l.filter { it.group == group }.sortedByDescending { it.id }
        if (mine.isEmpty()) return "Nothing to undo."
        val msgs = ArrayList<String>()
        for (e in mine) {
            msgs.add(applyUndo(e, root, memoryDelete))
            l.remove(e)
            bak(e.id).delete()
        }
        save(l)
        return msgs.joinToString("\n")
    }

    private fun applyUndo(e: UndoEntry, root: File, memoryDelete: (String, String) -> Int): String {
        return when (e.kind) {
            "file" -> restoreFile(e, root)
            "memory" -> if (memoryDelete(e.rel, e.payload) > 0) "Removed the saved memory \"${e.rel}\"." else "Memory \"${e.rel}\" was already gone."
            else -> "Unknown undo entry #${e.id}."
        }
    }

    private fun restoreFile(e: UndoEntry, root: File): String {
        val rootC = root.canonicalFile
        val fc = File(root, e.rel).canonicalFile
        if (!fc.path.startsWith(rootC.path + File.separator)) return "Refused: ${e.rel} is outside the sandbox."
        if (e.existed) {
            val b = bak(e.id)
            if (!b.isFile) return "Backup of ${e.rel} is missing."
            fc.parentFile?.mkdirs()
            b.copyTo(fc, overwrite = true)
            return "Restored ${e.rel} to its previous content."
        }
        return if (fc.delete()) "Deleted ${e.rel} (it did not exist before)." else "${e.rel} was already gone."
    }
}
