package com.swarmdeck.device

import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Pairing + request signing for the computer companion. Must stay byte-for-byte compatible with swarmdeck_companion.py
 * (known-answer tests in DeviceTest.kt use values computed by the Python side). Pure JVM.
 *
 * key = PBKDF2-HMAC-SHA256(normalized pairing code, salt, 100000 iterations, 32 bytes)
 * sig = HMAC-SHA256(key, "v1\n" + ts + "\n" + nonce + "\n" + body)
 */
object DeviceCrypto {
    const val ITERS = 100_000

    fun normalizeCode(code: String): String = code.trim().uppercase().replace("O", "0").replace("I", "1").replace("L", "1")

    fun deriveKey(code: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(normalizeCode(code).toCharArray(), salt, ITERS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun sign(key: ByteArray, ts: Long, nonce: String, body: ByteArray): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        mac.update("v1\n".toByteArray(Charsets.UTF_8))
        mac.update(ts.toString().toByteArray(Charsets.UTF_8))
        mac.update("\n".toByteArray(Charsets.UTF_8))
        mac.update(nonce.toByteArray(Charsets.UTF_8))
        mac.update("\n".toByteArray(Charsets.UTF_8))
        mac.update(body)
        return hex(mac.doFinal())
    }

    fun newNonce(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return hex(b)
    }

    fun hex(b: ByteArray): String {
        val sb = StringBuilder()
        for (x in b) sb.append(String.format("%02x", x))
        return sb.toString()
    }

    fun fromHex(s: String): ByteArray {
        val out = ByteArray(s.length / 2)
        for (i in out.indices) out[i] = s.substring(2 * i, 2 * i + 2).toInt(16).toByte()
        return out
    }
}
