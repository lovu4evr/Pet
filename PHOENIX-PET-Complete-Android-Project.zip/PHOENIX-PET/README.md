# PHOENIX PET — Android project

## Project structure
- `app/src/main/java/com/phoenix/pet/MainActivity.kt` — setup screen
- `PetOverlayService.kt` — floating draggable companion and menu
- `ChatActivity.kt` — text chat, speech recognition intent, Text-to-Speech
- `PetBrain.kt` — offline demo response logic (not an LLM)
- `app/src/main/AndroidManifest.xml` — app and overlay permissions
- `app/build.gradle.kts` — Android build and Java/Kotlin 17 targets
- `.github/workflows/android.yml` — GitHub Actions APK build

## Build with GitHub
1. Upload the CONTENTS of this ZIP to the root of a GitHub repository (not the ZIP file itself).
2. Keep `.github/workflows/android.yml` in that exact path.
3. Open Actions → Build Phoenix Pet APK → Run workflow.
4. Download `Phoenix-Pet-debug-APK` from the completed run's Artifacts section.

## Build locally
Use Android Studio with JDK 17 and Android SDK 35. Open this project folder and build the `app` debug variant.

## Important
- This is a starter implementation, not a production-ready AI assistant.
- `PetBrain` is an offline rule-based demo, not ChatGPT and not a local LLM.
- Voice recognition availability and network behavior depend on the speech service installed on the device.
- Android may require the user to manually grant "Display over other apps".
- Android 13+ may require notification permission. The sample keeps the notification permission declaration; request behavior may be added for your device flow.
- Android 14+ foreground-service rules and store policies may require additional declarations/review before Play Store distribution.
