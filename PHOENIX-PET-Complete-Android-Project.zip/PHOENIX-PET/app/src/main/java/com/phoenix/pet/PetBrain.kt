package com.phoenix.pet

object PetBrain {
    fun reply(raw: String): String {
        val message = raw.lowercase().trim()
        return when {
            message.contains("hello") || message == "hi" || message == "hey" ->
                "Hey! Phoenix systems are online. What are we building today?"
            message.contains("your name") || message.contains("who are you") ->
                "I'm PHOENIX PET, your floating Android companion."
            message.contains("time") ->
                "I don't have a live clock connection yet, but your device status bar shows the current time."
            message.contains("help") ->
                "I can chat, listen through your device's speech recognizer, speak replies, and stay on screen as a floating pet."
            message.contains("thank") ->
                "You're welcome! Ready for the next task."
            message.contains("joke") ->
                "Why did the robot visit the app store? It needed an update to its social life."
            else ->
                "I received: \"$raw\". I'm currently running in offline demo mode, so I can respond to simple patterns but I'm not connected to a large language model yet."
        }
    }
}
