package com.phoenix.pet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class ChatActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var transcript: LinearLayout
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private var lastReply = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 20, 16, 12)
            setBackgroundColor(0xFF07110D.toInt())
        }
        val heading = TextView(this).apply {
            text = "PHOENIX CHAT"
            textSize = 24f
            setTextColor(0xFF65FF9A.toInt())
            gravity = Gravity.CENTER
        }
        val scroll = ScrollView(this)
        transcript = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 16, 4, 16)
        }
        scroll.addView(transcript)
        input = EditText(this).apply {
            hint = "Message Phoenix..."
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9BB3A3.toInt())
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val send = Button(this).apply { text = "Send"; setOnClickListener { sendMessage() } }
        val voice = Button(this).apply { text = "Voice"; setOnClickListener { startVoiceInput() } }
        row.addView(send, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(voice, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val repeat = Button(this).apply {
            text = "Repeat reply"
            setOnClickListener { if (lastReply.isNotBlank()) speak(lastReply) }
        }
        root.addView(heading)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input)
        root.addView(row)
        root.addView(repeat)
        setContentView(root)
        addLine("Phoenix", "Hello! I'm Phoenix Pet. What should we work on?")
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        addLine("You", message)
        input.setText("")
        lastReply = PetBrain.reply(message)
        addLine("Phoenix", lastReply)
        speak(lastReply)
    }

    private fun addLine(who: String, text: String) {
        val line = TextView(this).apply {
            this.text = "$who: $text"
            textSize = 16f
            setTextColor(if (who == "Phoenix") 0xFF8BFFB0.toInt() else 0xFFFFFFFF.toInt())
            setPadding(8, 8, 8, 8)
        }
        transcript.addView(line)
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Phoenix")
        }
        try { startActivityForResult(intent, 70) } catch (_: Exception) {
            addLine("Phoenix", "Voice recognition isn't available on this device.")
        }
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 70 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                input.setText(spoken)
                sendMessage()
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "phoenix_reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
