package com.phoenix.pet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF07110D.toInt())
        }

        val title = TextView(this).apply {
            text = "PHOENIX PET"
            textSize = 30f
            setTextColor(0xFF65FF9A.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your floating AI companion"
            textSize = 15f
            setTextColor(0xFFD2E8DA.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }
        val start = makeButton("ENABLE FLOATING PET") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                )
            } else {
                startForegroundService(Intent(this, PetOverlayService::class.java))
            }
        }
        val chat = makeButton("OPEN CHAT") {
            startActivity(Intent(this, ChatActivity::class.java))
        }
        val stop = makeButton("STOP FLOATING PET") {
            stopService(Intent(this, PetOverlayService::class.java))
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(start)
        root.addView(chat)
        root.addView(stop)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 8, 0, 8) }
        }
}
