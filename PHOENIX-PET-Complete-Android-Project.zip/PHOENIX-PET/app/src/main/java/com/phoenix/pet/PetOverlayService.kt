package com.phoenix.pet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.animation.ObjectAnimator
import android.animation.ValueAnimator

class PetOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var petView: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private val faces = listOf("🤖", "😄", "🤔", "😴", "🎉", "✨")
    private var faceIndex = 0
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(41, notification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPet()
    }

    private fun showPet() {
        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val lp = WindowManager.LayoutParams(
            dp(72), dp(72), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = dp(180)
        }
        params = lp

        val pet = TextView(this).apply {
            text = faces[faceIndex]
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
            contentDescription = "Phoenix floating pet"
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = lp.x
                        startY = lp.y
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt()
                        val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(6)) moved = true
                        lp.x = startX + dx
                        lp.y = startY + dy
                        windowManager.updateViewLayout(this, lp)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) showMenu()
                        true
                    }
                    else -> true
                }
            }
        }
        petView = pet
        windowManager.addView(pet, lp)
        ObjectAnimator.ofFloat(pet, View.ALPHA, 0.72f, 1f).apply {
            duration = 1100
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun showMenu() {
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(0xEE10251A.toInt())
        }
        fun item(label: String, action: () -> Unit) {
            menu.addView(TextView(this).apply {
                text = label
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF79FFA7.toInt())
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setOnClickListener { action() }
            })
        }
        item("Change expression") {
            faceIndex = (faceIndex + 1) % faces.size
            petView?.text = faces[faceIndex]
            removeMenu(menu)
        }
        item("Open Phoenix Chat") {
            removeMenu(menu)
            startActivity(Intent(this, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        item("Say hello") {
            petView?.text = "👋"
            removeMenu(menu)
        }
        item("Close menu") { removeMenu(menu) }

        val menuParams = WindowManager.LayoutParams(
            dp(190), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (params?.x ?: dp(18)) + dp(76)
            y = params?.y ?: dp(180)
        }
        try {
            windowManager.addView(menu, menuParams)
            menu.tag = menuParams
        } catch (_: Exception) { }
    }

    private fun removeMenu(menu: View) {
        try { windowManager.removeView(menu) } catch (_: Exception) { }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("phoenix_pet", "Phoenix Pet", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "phoenix_pet")
                .setContentTitle("PHOENIX PET is active")
                .setContentText("Tap to manage your floating companion")
                .setSmallIcon(android.R.drawable.sym_def_app_icon)
                .setContentIntent(open)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("PHOENIX PET is active")
                .setContentText("Your floating companion is running")
                .setSmallIcon(android.R.drawable.sym_def_app_icon)
                .setContentIntent(open)
                .build()
        }
    }

    override fun onDestroy() {
        petView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        petView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
